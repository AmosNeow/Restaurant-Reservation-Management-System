﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HEXI_IOOP
{
    internal class UserProfile
    {
        public int userid { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public int age { get; set; }
        public string role { get; set; }
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Admin"].ToString());

        public UserProfile(int ui, string un, string pss, string em, string ph, int ag, string rl)
        {
            userid = ui;
            username = un;
            password = pss;
            email = em;
            phone = ph;
            age = ag;
            role = rl;
        }

        public static ArrayList ViewUPData()
        {
            ArrayList profile = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Users", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string result = $"{rd["User_ID"]}\t{rd["Name"]}\t{rd["Role"]}\t{rd["Age"]}\t{rd["Phone_number"]}\t{rd["Email"]}\t{rd["Password"]}";
                profile.Add(result);
            }
            con.Close();
            return profile;
        }
    }
}
