﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_Order : Form
    {

        private int loggedInUserId;
        int userId = User.LoggedInUser.UserId;
        private static List<OrderItem> orderList = new List<OrderItem>();

        public Customer_Order()
        {
            InitializeComponent();
            loggedInUserId = userId; 
            LoadCategories();
        }

        private void LoadCategories()
        {
            combCategory.Items.Clear();
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
            {
                con.Open();
                string query = "SELECT DISTINCT Category FROM Menu";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    combCategory.Items.Add(reader["Category"].ToString());
                }
                reader.Close();
            }
        }

        // Load Food Items Based on Selected Category
        private void combCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            combFood.Items.Clear();
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
            {
                con.Open();
                string query = "SELECT Name FROM Menu WHERE Category = @Category";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Category", combCategory.SelectedItem.ToString());
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    combFood.Items.Add(reader["Name"].ToString());
                }
                reader.Close();
            }
        }

        private void combFood_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
            {
                con.Open();
                string query = "SELECT Price, Food_Id FROM Menu WHERE Name = @Name";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Name", combFood.SelectedItem.ToString());
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    lblUnitPrice.Text = $"RM {reader["Price"].ToString()}";
                    lblFoodId.Text = reader["Food_Id"].ToString(); 
                }
                reader.Close();
            }
        }

        List<OrderItem> orders = new List<OrderItem>();
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (combCategory.SelectedIndex == -1 || combFood.SelectedIndex == -1 || numQuantity.Value <= 0)
            {
                MessageBox.Show("Please select a category, food item, and valid quantity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int foodId = Convert.ToInt32(lblFoodId.Text);
            string name = combFood.Text;
            string category = combCategory.Text;
            decimal unitPrice = Convert.ToDecimal(lblUnitPrice.Text.Replace("RM ", ""));
            int quantity = (int)numQuantity.Value;

            OrderItem.AddOrder(foodId, name, category, unitPrice, quantity, listOrder, lblTotalAmount, orderList);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (orderList.Count == 0)
            {
                MessageBox.Show("Your order list is empty. Please add items before proceeding.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            
            OrderItem.SaveOrderToDatabase(loggedInUserId, orderList);

            
            orderList.Clear();
            listOrder.Items.Clear();
            lblTotalAmount.Text = "RM 0.00";

            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }

        private void listOrder_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            OrderItem.DeleteOrder(orderList, listOrder, lblTotalAmount);
        }

        private void btnEditOrder_Click(object sender, EventArgs e)
        {
            if (listOrder.SelectedItem == null)
            {
                MessageBox.Show("Please select an item in the order listbox to edit.");
                return;
            }

            string selectedItem = listOrder.SelectedItem.ToString();
            var match = Regex.Match(selectedItem, @"^(.*?)\s*\(x(\d+)\)");

            if (!match.Success)
            {
                MessageBox.Show("Error: Could not extract quantity. Check format.");
                return;
            }

            string itemName = match.Groups[1].Value.Trim();
            int quantity = int.Parse(match.Groups[2].Value);

            // Open Edit Form
            EditOrderForm editForm = new EditOrderForm(itemName, quantity);
            if (editForm.ShowDialog() != DialogResult.OK) return;

            int updatedQuantity = editForm.GetUpdatedQuantity();
            decimal unitPrice = OrderItem.GetUnitPriceByName(itemName, orderList);

            // Update UI & Order List
            listOrder.Items[listOrder.SelectedIndex] = $"{itemName} (x{updatedQuantity}) - RM {updatedQuantity * unitPrice:F2}";
            orderList.FirstOrDefault(item => item.GetName() == itemName)?.UpdateQuantity(updatedQuantity);

            // Refresh total amount
            OrderItem.UpdateTotalAmount(lblTotalAmount, orderList);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }
    }
}