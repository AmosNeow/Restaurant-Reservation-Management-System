﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace group_assignment__IOOP_
{
    internal class HallDetails
    {
        private int Hall_id { get; set; }
        public int Capacity { get; set; }
        public int Price { get; set; }
        public HallDetails(int hall_id, int capacity, int price)
        {
            Hall_id = hall_id;
            Capacity = capacity;
            Price = price;
        }

        public HallDetails(int capacity, int price)
        {
            Capacity = capacity;
            Price = price;
        }
    }
}
