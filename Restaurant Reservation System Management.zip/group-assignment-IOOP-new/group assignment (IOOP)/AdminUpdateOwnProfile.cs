﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class AdminUpdateOwnProfile: Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminUpdateOwnProfile()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminHomePage adminmenu = new AdminHomePage();
            adminmenu.Show();
            this.Close();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(IDComboBox.Text) || // check if the fields are empty
                string.IsNullOrWhiteSpace(NameTxt.Text) ||
                string.IsNullOrWhiteSpace(AgeTxt.Text) ||
                string.IsNullOrWhiteSpace(PhoneTxt.Text) ||
                string.IsNullOrWhiteSpace(EmailTxt.Text) ||
                string.IsNullOrWhiteSpace(PasswordTxt.Text))
                {
                    MessageBox.Show("All fields must be filled out before saving.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // return to stop the function
                }
                else
                {
                    int userid = Convert.ToInt32(IDComboBox.SelectedValue);
                    string username = NameTxt.Text;
                    string password = PasswordTxt.Text;
                    string email = EmailTxt.Text;
                    string phone = PhoneTxt.Text;
                    int age = Convert.ToInt32(AgeTxt.Text);
                    UserProfile up = new UserProfile(userid, username, password, email, phone, age);
                    up.UpdateOP();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Age must be integer. Please try again.");  // show error message
            }
        }

        private void PasswordTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void AdminUpdateOwnProfile_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT User_Id FROM Users", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            IDComboBox.DataSource = dt;
            IDComboBox.DisplayMember = "User_Id";
            IDComboBox.ValueMember = "User_Id";
        }

        private void IDComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
