﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class AdminDeleteUserProfilecs: Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminDeleteUserProfilecs()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminManageUserProfile manageuserprofile = new AdminManageUserProfile();
            manageuserprofile.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminManageUserProfile manageuserprofile = new AdminManageUserProfile();
            manageuserprofile.Close();
            AdminHomePage adminmenu = new AdminHomePage();
            adminmenu.Close();
            Close();
        }

        private void NameTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            int deleteid = Convert.ToInt32(IDComboBox.SelectedValue);
            UserProfile up = new UserProfile(deleteid);
            up.DeleteUP();
        }

        private void AdminDeleteUserProfilecs_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT User_Id FROM Users", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            IDComboBox.DataSource = dt;
            IDComboBox.DisplayMember = "User_Id";
            IDComboBox.ValueMember = "User_Id";
        }
    }
}
