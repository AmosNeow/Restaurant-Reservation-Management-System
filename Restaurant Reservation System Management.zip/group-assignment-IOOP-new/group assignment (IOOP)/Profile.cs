﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    internal class Profile
    {
        string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

        public bool UpdateProfile(string field, string value)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = $"UPDATE Users SET {field} = @Value WHERE Role = 'Manager'";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Value", value);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating profile: {ex.Message}");
                return false;
            }

        }
    }
}
