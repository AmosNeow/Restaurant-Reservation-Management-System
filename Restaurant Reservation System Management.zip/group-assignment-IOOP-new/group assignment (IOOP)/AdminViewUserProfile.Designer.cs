﻿namespace group_assignment__IOOP_
{
    partial class AdminViewUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminViewUserProfile));
            this.ViewUserProfileMenu = new System.Windows.Forms.Label();
            this.MessageLabel = new System.Windows.Forms.Label();
            this.BackBtn = new System.Windows.Forms.Button();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listViewUP = new System.Windows.Forms.ListView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewUserProfileMenu
            // 
            this.ViewUserProfileMenu.AutoSize = true;
            this.ViewUserProfileMenu.BackColor = System.Drawing.SystemColors.Highlight;
            this.ViewUserProfileMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ViewUserProfileMenu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewUserProfileMenu.Location = new System.Drawing.Point(-12, -2);
            this.ViewUserProfileMenu.MinimumSize = new System.Drawing.Size(820, 50);
            this.ViewUserProfileMenu.Name = "ViewUserProfileMenu";
            this.ViewUserProfileMenu.Size = new System.Drawing.Size(820, 50);
            this.ViewUserProfileMenu.TabIndex = 2;
            this.ViewUserProfileMenu.Text = "   View User Profile";
            this.ViewUserProfileMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-12, 402);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 8;
            this.MessageLabel.Text = "      Luna : Here is all user profiles.";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MessageLabel.Click += new System.EventHandler(this.MessageLabel_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Location = new System.Drawing.Point(453, 316);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(198, 35);
            this.BackBtn.TabIndex = 12;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(27, 90);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-12, -38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(933, 490);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // listViewUP
            // 
            this.listViewUP.FullRowSelect = true;
            this.listViewUP.GridLines = true;
            this.listViewUP.HideSelection = false;
            this.listViewUP.Location = new System.Drawing.Point(320, 90);
            this.listViewUP.MultiSelect = false;
            this.listViewUP.Name = "listViewUP";
            this.listViewUP.Size = new System.Drawing.Size(455, 205);
            this.listViewUP.TabIndex = 43;
            this.listViewUP.UseCompatibleStateImageBehavior = false;
            this.listViewUP.View = System.Windows.Forms.View.Details;
            // 
            // AdminViewUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listViewUP);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.ViewUserProfileMenu);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminViewUserProfile";
            this.Text = "AdminViewUserProfile";
            this.Load += new System.EventHandler(this.AdminViewUserProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ViewUserProfileMenu;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewUP;
    }
}