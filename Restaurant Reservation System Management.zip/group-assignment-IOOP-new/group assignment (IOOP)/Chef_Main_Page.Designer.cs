﻿namespace IOOP_assignment
{
    partial class frmChefMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChefMenu));
            this.background = new System.Windows.Forms.PictureBox();
            this.lblChef = new System.Windows.Forms.Label();
            this.btnViewIngredients = new System.Windows.Forms.Button();
            this.btnChefProfile = new System.Windows.Forms.Button();
            this.btnViewOrders = new System.Windows.Forms.Button();
            this.btnGoToLogIn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            this.SuspendLayout();
            // 
            // background
            // 
            this.background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background.Image = ((System.Drawing.Image)(resources.GetObject("background.Image")));
            this.background.Location = new System.Drawing.Point(0, 0);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(1131, 695);
            this.background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background.TabIndex = 0;
            this.background.TabStop = false;
            // 
            // lblChef
            // 
            this.lblChef.AutoSize = true;
            this.lblChef.Font = new System.Drawing.Font("MV Boli", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChef.Location = new System.Drawing.Point(70, 47);
            this.lblChef.Name = "lblChef";
            this.lblChef.Size = new System.Drawing.Size(209, 105);
            this.lblChef.TabIndex = 1;
            this.lblChef.Text = "Chef";
            // 
            // btnViewIngredients
            // 
            this.btnViewIngredients.Font = new System.Drawing.Font("MV Boli", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewIngredients.Location = new System.Drawing.Point(403, 322);
            this.btnViewIngredients.Name = "btnViewIngredients";
            this.btnViewIngredients.Size = new System.Drawing.Size(338, 179);
            this.btnViewIngredients.TabIndex = 2;
            this.btnViewIngredients.Text = "View Ingredients";
            this.btnViewIngredients.UseVisualStyleBackColor = true;
            this.btnViewIngredients.Click += new System.EventHandler(this.btnViewIngredients_Click);
            // 
            // btnChefProfile
            // 
            this.btnChefProfile.Font = new System.Drawing.Font("MV Boli", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChefProfile.Location = new System.Drawing.Point(762, 322);
            this.btnChefProfile.Name = "btnChefProfile";
            this.btnChefProfile.Size = new System.Drawing.Size(338, 179);
            this.btnChefProfile.TabIndex = 3;
            this.btnChefProfile.Text = "Update Profile";
            this.btnChefProfile.UseVisualStyleBackColor = true;
            this.btnChefProfile.Click += new System.EventHandler(this.btnChefProfile_Click);
            // 
            // btnViewOrders
            // 
            this.btnViewOrders.Font = new System.Drawing.Font("MV Boli", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewOrders.Location = new System.Drawing.Point(41, 322);
            this.btnViewOrders.Name = "btnViewOrders";
            this.btnViewOrders.Size = new System.Drawing.Size(338, 179);
            this.btnViewOrders.TabIndex = 4;
            this.btnViewOrders.Text = "View Orders";
            this.btnViewOrders.UseVisualStyleBackColor = true;
            this.btnViewOrders.Click += new System.EventHandler(this.btnViewOrders_Click);
            // 
            // btnGoToLogIn
            // 
            this.btnGoToLogIn.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoToLogIn.Location = new System.Drawing.Point(886, 580);
            this.btnGoToLogIn.Name = "btnGoToLogIn";
            this.btnGoToLogIn.Size = new System.Drawing.Size(192, 91);
            this.btnGoToLogIn.TabIndex = 5;
            this.btnGoToLogIn.Text = "Go To Log In";
            this.btnGoToLogIn.UseVisualStyleBackColor = true;
            this.btnGoToLogIn.Click += new System.EventHandler(this.btnGoToLogIn_Click);
            // 
            // frmChefMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1131, 695);
            this.Controls.Add(this.btnGoToLogIn);
            this.Controls.Add(this.btnViewOrders);
            this.Controls.Add(this.btnChefProfile);
            this.Controls.Add(this.btnViewIngredients);
            this.Controls.Add(this.lblChef);
            this.Controls.Add(this.background);
            this.Name = "frmChefMenu";
            this.Text = "Chef Menu";
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox background;
        private System.Windows.Forms.Label lblChef;
        private System.Windows.Forms.Button btnViewIngredients;
        private System.Windows.Forms.Button btnChefProfile;
        private System.Windows.Forms.Button btnViewOrders;
        private System.Windows.Forms.Button btnGoToLogIn;
    }
}

