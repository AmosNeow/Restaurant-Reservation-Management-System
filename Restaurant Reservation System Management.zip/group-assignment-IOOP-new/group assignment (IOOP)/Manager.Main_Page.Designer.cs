﻿namespace group_assignment__IOOP_
{
    partial class Main_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Page));
            this.BttnEP = new System.Windows.Forms.Button();
            this.BttnVHR = new System.Windows.Forms.Button();
            this.BttnMH = new System.Windows.Forms.Button();
            this.BttnMM = new System.Windows.Forms.Button();
            this.LBLMMP = new System.Windows.Forms.Label();
            this.LogOutBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BttnEP
            // 
            this.BttnEP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnEP.Location = new System.Drawing.Point(418, 230);
            this.BttnEP.Name = "BttnEP";
            this.BttnEP.Size = new System.Drawing.Size(159, 46);
            this.BttnEP.TabIndex = 16;
            this.BttnEP.Text = "Edit Profile";
            this.BttnEP.UseVisualStyleBackColor = true;
            this.BttnEP.Click += new System.EventHandler(this.BttnMP_Click);
            // 
            // BttnVHR
            // 
            this.BttnVHR.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnVHR.Location = new System.Drawing.Point(168, 235);
            this.BttnVHR.Name = "BttnVHR";
            this.BttnVHR.Size = new System.Drawing.Size(206, 41);
            this.BttnVHR.TabIndex = 15;
            this.BttnVHR.Text = "View Hall Reservation";
            this.BttnVHR.UseVisualStyleBackColor = true;
            this.BttnVHR.Click += new System.EventHandler(this.BttnVHR_Click);
            // 
            // BttnMH
            // 
            this.BttnMH.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnMH.Location = new System.Drawing.Point(418, 148);
            this.BttnMH.Name = "BttnMH";
            this.BttnMH.Size = new System.Drawing.Size(148, 46);
            this.BttnMH.TabIndex = 14;
            this.BttnMH.Text = "Manage Hall";
            this.BttnMH.UseVisualStyleBackColor = true;
            this.BttnMH.Click += new System.EventHandler(this.BttnMH_Click);
            // 
            // BttnMM
            // 
            this.BttnMM.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnMM.Location = new System.Drawing.Point(168, 148);
            this.BttnMM.Name = "BttnMM";
            this.BttnMM.Size = new System.Drawing.Size(155, 43);
            this.BttnMM.TabIndex = 13;
            this.BttnMM.Text = "Manage Menu";
            this.BttnMM.UseVisualStyleBackColor = true;
            this.BttnMM.Click += new System.EventHandler(this.BttnMM_Click);
            // 
            // LBLMMP
            // 
            this.LBLMMP.AutoSize = true;
            this.LBLMMP.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLMMP.Location = new System.Drawing.Point(261, 26);
            this.LBLMMP.Name = "LBLMMP";
            this.LBLMMP.Size = new System.Drawing.Size(219, 28);
            this.LBLMMP.TabIndex = 12;
            this.LBLMMP.Text = "Manager Main Page";
            // 
            // LogOutBtn
            // 
            this.LogOutBtn.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutBtn.Location = new System.Drawing.Point(646, 11);
            this.LogOutBtn.Margin = new System.Windows.Forms.Padding(2);
            this.LogOutBtn.Name = "LogOutBtn";
            this.LogOutBtn.Size = new System.Drawing.Size(83, 30);
            this.LogOutBtn.TabIndex = 26;
            this.LogOutBtn.Text = "Log Out";
            this.LogOutBtn.UseVisualStyleBackColor = true;
            this.LogOutBtn.Click += new System.EventHandler(this.LogOutBtn_Click);
            // 
            // Main_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LogOutBtn);
            this.Controls.Add(this.BttnMM);
            this.Controls.Add(this.BttnMH);
            this.Controls.Add(this.BttnEP);
            this.Controls.Add(this.BttnVHR);
            this.Controls.Add(this.LBLMMP);
            this.Name = "Main_Page";
            this.Text = "Main_Page";
            this.Load += new System.EventHandler(this.Main_Page_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BttnEP;
        private System.Windows.Forms.Button BttnVHR;
        private System.Windows.Forms.Button BttnMH;
        private System.Windows.Forms.Button BttnMM;
        private System.Windows.Forms.Label LBLMMP;
        private System.Windows.Forms.Button LogOutBtn;
    }
}