﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class View_Hall : Form
    {
        public View_Hall()
        {
            InitializeComponent();
        }

        private void LoadTable()
        {
            LSBHRT.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            // Step 2: Query the database
            string query = "SELECT * FROM Reservation_Details";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Step 3: Execute the command
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    // Step 4: Load data into ListBox

                    while (reader.Read())
                    {
                        List<string> rowData = new List<string>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            rowData.Add(reader.GetValue(i).ToString().PadRight(9)); // Adjust width dynamically
                        }

                        LSBHRT.Items.Add(string.Join(" ", rowData));
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void lblHRT_Click(object sender, EventArgs e)
        {

        }

        private void BttnExit_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Main_Page form2 = new Main_Page();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void View_Hall_Load(object sender, EventArgs e)
        {
            LoadTable();
        }

        private void lblTheme_Click(object sender, EventArgs e)
        {

        }

        private void lblReservationid_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
