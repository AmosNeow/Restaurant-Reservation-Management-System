﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using group_assignment__IOOP_;
using MOK_IOOPassignment;

namespace IOOP_assignment
{
    public partial class frmChefMenu : Form
    {
        public frmChefMenu()
        {
            InitializeComponent();
        }

        private void btnViewOrders_Click(object sender, EventArgs e)
        {
            frmViewOrders b = new frmViewOrders();
            Chef_Class.Change_Form(this, b);
        }
        private void btnViewIngredients_Click(object sender, EventArgs e)
        {
            frmViewIngredients k = new frmViewIngredients();
            Chef_Class.Change_Form(this, k);
        }
        private void btnChefProfile_Click(object sender, EventArgs e)
        {
            Chef_UpdateProfile a = new Chef_UpdateProfile();
            Chef_Class.Change_Form (this, a);
        }

        private void btnGoToLogIn_Click(object sender, EventArgs e)
        {
            LogIn a = new LogIn();
            Chef_Class.Change_Form(this, a);
        }
    }
}
