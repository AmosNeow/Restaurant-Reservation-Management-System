﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class AdminCustomerFeedback: Form
    {
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminCustomerFeedback()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminHomePage adminmenu = new AdminHomePage();
            adminmenu.Show();
            Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void ListFeedback_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        public static ArrayList ViewCFData()
        {
            ArrayList feedback = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Order_Customer_Feedback", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string result = $"{rd["User_ID"]}\t{rd["Feedback"]}";
                feedback.Add(result);
            }
            con.Close();
            return feedback;
        }
        public void ListViewCustomerFeedback()
        {
            listViewCF.Items.Clear();
            listViewCF.View = View.Details;
            listViewCF.Columns.Add("User ID", 100, HorizontalAlignment.Left);
            listViewCF.Columns.Add("Feedback", 100, HorizontalAlignment.Left);

            ArrayList profile1 = ViewCFData();
            foreach (var item in profile1)
            {
                string[] row = item.ToString().Split('\t');
                ListViewItem listViewItem = new ListViewItem(row[0]);
                for (int i = 1; i < row.Length; i++)
                {
                    listViewItem.SubItems.Add(row[i]);
                }
                listViewCF.Items.Add(listViewItem);
            }

        }

        private void AdminCustomerFeedback_Load(object sender, EventArgs e)
        {
            ListViewCustomerFeedback();
        }
    }
}
