﻿using System;

namespace group_assignment__IOOP_
{
    partial class Manage_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
         this.Load += new EventHandler(Manage_Menu_Load);

        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manage_Menu));
            this.bttnEM = new System.Windows.Forms.Button();
            this.bttnDM = new System.Windows.Forms.Button();
            this.bttnAM = new System.Windows.Forms.Button();
            this.LBLMM = new System.Windows.Forms.Label();
            this.BttnExit = new System.Windows.Forms.Button();
            this.LSBMenu = new System.Windows.Forms.ListBox();
            this.TXTBNF = new System.Windows.Forms.TextBox();
            this.LBNewName = new System.Windows.Forms.Label();
            this.LBCategories = new System.Windows.Forms.Label();
            this.NewPrice = new System.Windows.Forms.Label();
            this.TXTBCategory = new System.Windows.Forms.TextBox();
            this.TXTBPrice = new System.Windows.Forms.TextBox();
            this.LBLEP = new System.Windows.Forms.Label();
            this.TXTBNP = new System.Windows.Forms.TextBox();
            this.TXTBFN = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LBLIDN = new System.Windows.Forms.Label();
            this.TXTBDR = new System.Windows.Forms.TextBox();
            this.lblFood = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bttnEM
            // 
            this.bttnEM.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnEM.Location = new System.Drawing.Point(688, 490);
            this.bttnEM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bttnEM.Name = "bttnEM";
            this.bttnEM.Size = new System.Drawing.Size(131, 39);
            this.bttnEM.TabIndex = 10;
            this.bttnEM.Text = "Edit Price";
            this.bttnEM.UseVisualStyleBackColor = true;
            this.bttnEM.Click += new System.EventHandler(this.bttnEM_Click);
            // 
            // bttnDM
            // 
            this.bttnDM.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnDM.Location = new System.Drawing.Point(355, 495);
            this.bttnDM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bttnDM.Name = "bttnDM";
            this.bttnDM.Size = new System.Drawing.Size(159, 39);
            this.bttnDM.TabIndex = 9;
            this.bttnDM.Text = "Delete Menu";
            this.bttnDM.UseVisualStyleBackColor = true;
            this.bttnDM.Click += new System.EventHandler(this.bttnDM_Click);
            // 
            // bttnAM
            // 
            this.bttnAM.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnAM.Location = new System.Drawing.Point(89, 495);
            this.bttnAM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bttnAM.Name = "bttnAM";
            this.bttnAM.Size = new System.Drawing.Size(136, 44);
            this.bttnAM.TabIndex = 8;
            this.bttnAM.Text = "Add Menu";
            this.bttnAM.UseVisualStyleBackColor = true;
            this.bttnAM.Click += new System.EventHandler(this.bttnAM_Click);
            // 
            // LBLMM
            // 
            this.LBLMM.AutoSize = true;
            this.LBLMM.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLMM.Location = new System.Drawing.Point(16, 7);
            this.LBLMM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLMM.Name = "LBLMM";
            this.LBLMM.Size = new System.Drawing.Size(199, 34);
            this.LBLMM.TabIndex = 6;
            this.LBLMM.Text = "Manage Menu";
            // 
            // BttnExit
            // 
            this.BttnExit.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnExit.Location = new System.Drawing.Point(952, 500);
            this.BttnExit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BttnExit.Name = "BttnExit";
            this.BttnExit.Size = new System.Drawing.Size(99, 39);
            this.BttnExit.TabIndex = 11;
            this.BttnExit.Text = "Exit";
            this.BttnExit.UseVisualStyleBackColor = true;
            this.BttnExit.Click += new System.EventHandler(this.BttnExit_Click);
            // 
            // LSBMenu
            // 
            this.LSBMenu.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LSBMenu.FormattingEnabled = true;
            this.LSBMenu.ItemHeight = 26;
            this.LSBMenu.Location = new System.Drawing.Point(116, 86);
            this.LSBMenu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.LSBMenu.Name = "LSBMenu";
            this.LSBMenu.Size = new System.Drawing.Size(860, 186);
            this.LSBMenu.TabIndex = 12;
            this.LSBMenu.SelectedIndexChanged += new System.EventHandler(this.LSBMenu_SelectedIndexChanged);
            // 
            // TXTBNF
            // 
            this.TXTBNF.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBNF.Location = new System.Drawing.Point(149, 341);
            this.TXTBNF.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TXTBNF.Name = "TXTBNF";
            this.TXTBNF.Size = new System.Drawing.Size(132, 40);
            this.TXTBNF.TabIndex = 13;
            // 
            // LBNewName
            // 
            this.LBNewName.AutoSize = true;
            this.LBNewName.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBNewName.Location = new System.Drawing.Point(17, 345);
            this.LBNewName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBNewName.Name = "LBNewName";
            this.LBNewName.Size = new System.Drawing.Size(114, 26);
            this.LBNewName.TabIndex = 14;
            this.LBNewName.Text = "New Food:";
            // 
            // LBCategories
            // 
            this.LBCategories.AutoSize = true;
            this.LBCategories.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBCategories.Location = new System.Drawing.Point(32, 393);
            this.LBCategories.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBCategories.Name = "LBCategories";
            this.LBCategories.Size = new System.Drawing.Size(102, 26);
            this.LBCategories.TabIndex = 15;
            this.LBCategories.Text = "Category:";
            // 
            // NewPrice
            // 
            this.NewPrice.AutoSize = true;
            this.NewPrice.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPrice.Location = new System.Drawing.Point(68, 442);
            this.NewPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NewPrice.Name = "NewPrice";
            this.NewPrice.Size = new System.Drawing.Size(65, 26);
            this.NewPrice.TabIndex = 16;
            this.NewPrice.Text = "Price:";
            // 
            // TXTBCategory
            // 
            this.TXTBCategory.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBCategory.Location = new System.Drawing.Point(149, 389);
            this.TXTBCategory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TXTBCategory.Name = "TXTBCategory";
            this.TXTBCategory.Size = new System.Drawing.Size(132, 40);
            this.TXTBCategory.TabIndex = 17;
            // 
            // TXTBPrice
            // 
            this.TXTBPrice.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBPrice.Location = new System.Drawing.Point(149, 442);
            this.TXTBPrice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TXTBPrice.Name = "TXTBPrice";
            this.TXTBPrice.Size = new System.Drawing.Size(132, 40);
            this.TXTBPrice.TabIndex = 18;
            // 
            // LBLEP
            // 
            this.LBLEP.AutoSize = true;
            this.LBLEP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLEP.Location = new System.Drawing.Point(624, 406);
            this.LBLEP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLEP.Name = "LBLEP";
            this.LBLEP.Size = new System.Drawing.Size(116, 26);
            this.LBLEP.TabIndex = 20;
            this.LBLEP.Text = "New Price:";
            // 
            // TXTBNP
            // 
            this.TXTBNP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBNP.Location = new System.Drawing.Point(757, 402);
            this.TXTBNP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TXTBNP.Name = "TXTBNP";
            this.TXTBNP.Size = new System.Drawing.Size(132, 40);
            this.TXTBNP.TabIndex = 21;
            // 
            // TXTBFN
            // 
            this.TXTBFN.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBFN.Location = new System.Drawing.Point(757, 354);
            this.TXTBFN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TXTBFN.Name = "TXTBFN";
            this.TXTBFN.Size = new System.Drawing.Size(132, 40);
            this.TXTBFN.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(615, 358);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 26);
            this.label1.TabIndex = 23;
            this.label1.Text = "Food Name:";
            // 
            // LBLIDN
            // 
            this.LBLIDN.AutoSize = true;
            this.LBLIDN.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLIDN.Location = new System.Drawing.Point(307, 389);
            this.LBLIDN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLIDN.Name = "LBLIDN";
            this.LBLIDN.Size = new System.Drawing.Size(123, 26);
            this.LBLIDN.TabIndex = 24;
            this.LBLIDN.Text = "ID Number:";
            // 
            // TXTBDR
            // 
            this.TXTBDR.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBDR.Location = new System.Drawing.Point(448, 378);
            this.TXTBDR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TXTBDR.Name = "TXTBDR";
            this.TXTBDR.Size = new System.Drawing.Size(132, 40);
            this.TXTBDR.TabIndex = 25;
            // 
            // lblFood
            // 
            this.lblFood.AutoSize = true;
            this.lblFood.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFood.Location = new System.Drawing.Point(123, 56);
            this.lblFood.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFood.Name = "lblFood";
            this.lblFood.Size = new System.Drawing.Size(81, 26);
            this.lblFood.TabIndex = 26;
            this.lblFood.Text = "Food_id";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(324, 57);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(65, 26);
            this.lblName.TabIndex = 27;
            this.lblName.Text = "Name";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(556, 57);
            this.lblCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(95, 26);
            this.lblCategory.TabIndex = 28;
            this.lblCategory.Text = "Category";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(787, 57);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(58, 26);
            this.lblPrice.TabIndex = 29;
            this.lblPrice.Text = "Price";
            // 
            // Manage_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblFood);
            this.Controls.Add(this.TXTBDR);
            this.Controls.Add(this.LBLIDN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TXTBFN);
            this.Controls.Add(this.TXTBNP);
            this.Controls.Add(this.LBLEP);
            this.Controls.Add(this.TXTBPrice);
            this.Controls.Add(this.TXTBCategory);
            this.Controls.Add(this.NewPrice);
            this.Controls.Add(this.LBCategories);
            this.Controls.Add(this.LBNewName);
            this.Controls.Add(this.TXTBNF);
            this.Controls.Add(this.LSBMenu);
            this.Controls.Add(this.BttnExit);
            this.Controls.Add(this.bttnEM);
            this.Controls.Add(this.bttnDM);
            this.Controls.Add(this.bttnAM);
            this.Controls.Add(this.LBLMM);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Manage_Menu";
            this.Text = "Manage_Menu";
            this.Load += new System.EventHandler(this.Manage_Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttnEM;
        private System.Windows.Forms.Button bttnDM;
        private System.Windows.Forms.Button bttnAM;
        private System.Windows.Forms.Label LBLMM;
        private System.Windows.Forms.Button BttnExit;
        private System.Windows.Forms.ListBox LSBMenu;
        private System.Windows.Forms.TextBox TXTBNF;
        private System.Windows.Forms.Label LBNewName;
        private System.Windows.Forms.Label LBCategories;
        private System.Windows.Forms.Label NewPrice;
        private System.Windows.Forms.TextBox TXTBCategory;
        private System.Windows.Forms.TextBox TXTBPrice;
        private System.Windows.Forms.Label LBLEP;
        private System.Windows.Forms.TextBox TXTBNP;
        private System.Windows.Forms.TextBox TXTBFN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LBLIDN;
        private System.Windows.Forms.TextBox TXTBDR;
        private System.Windows.Forms.Label lblFood;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblPrice;
    }
    }