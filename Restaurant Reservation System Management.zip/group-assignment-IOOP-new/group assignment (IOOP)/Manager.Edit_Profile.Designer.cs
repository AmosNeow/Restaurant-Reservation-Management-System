﻿namespace group_assignment__IOOP_
{
    partial class Edit_Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Edit_Profile));
            this.TXTBNI = new System.Windows.Forms.TextBox();
            this.lblNI = new System.Windows.Forms.Label();
            this.CBBEdit = new System.Windows.Forms.ComboBox();
            this.lblEI = new System.Windows.Forms.Label();
            this.BttnExit = new System.Windows.Forms.Button();
            this.BTTNEP = new System.Windows.Forms.Button();
            this.LBLMH = new System.Windows.Forms.Label();
            this.LSBVP = new System.Windows.Forms.ListBox();
            this.LBLUI = new System.Windows.Forms.Label();
            this.LBLName = new System.Windows.Forms.Label();
            this.LBLRole = new System.Windows.Forms.Label();
            this.LBLAge = new System.Windows.Forms.Label();
            this.LBLPN = new System.Windows.Forms.Label();
            this.LBLEmail = new System.Windows.Forms.Label();
            this.LBLPassword = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TXTBNI
            // 
            this.TXTBNI.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBNI.Location = new System.Drawing.Point(577, 267);
            this.TXTBNI.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBNI.Name = "TXTBNI";
            this.TXTBNI.Size = new System.Drawing.Size(160, 40);
            this.TXTBNI.TabIndex = 17;
            // 
            // lblNI
            // 
            this.lblNI.AutoSize = true;
            this.lblNI.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNI.Location = new System.Drawing.Point(307, 282);
            this.lblNI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNI.Name = "lblNI";
            this.lblNI.Size = new System.Drawing.Size(180, 26);
            this.lblNI.TabIndex = 16;
            this.lblNI.Text = "New Information:";
            // 
            // CBBEdit
            // 
            this.CBBEdit.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBBEdit.FormattingEnabled = true;
            this.CBBEdit.Location = new System.Drawing.Point(577, 174);
            this.CBBEdit.Margin = new System.Windows.Forms.Padding(4);
            this.CBBEdit.Name = "CBBEdit";
            this.CBBEdit.Size = new System.Drawing.Size(160, 34);
            this.CBBEdit.TabIndex = 15;
            // 
            // lblEI
            // 
            this.lblEI.AutoSize = true;
            this.lblEI.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEI.Location = new System.Drawing.Point(303, 183);
            this.lblEI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEI.Name = "lblEI";
            this.lblEI.Size = new System.Drawing.Size(178, 26);
            this.lblEI.TabIndex = 14;
            this.lblEI.Text = "Edit Information:";
            // 
            // BttnExit
            // 
            this.BttnExit.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnExit.Location = new System.Drawing.Point(940, 505);
            this.BttnExit.Margin = new System.Windows.Forms.Padding(4);
            this.BttnExit.Name = "BttnExit";
            this.BttnExit.Size = new System.Drawing.Size(111, 34);
            this.BttnExit.TabIndex = 18;
            this.BttnExit.Text = "Exit";
            this.BttnExit.UseVisualStyleBackColor = true;
            this.BttnExit.Click += new System.EventHandler(this.BttnExit_Click);
            // 
            // BTTNEP
            // 
            this.BTTNEP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTTNEP.Location = new System.Drawing.Point(461, 422);
            this.BTTNEP.Margin = new System.Windows.Forms.Padding(4);
            this.BTTNEP.Name = "BTTNEP";
            this.BTTNEP.Size = new System.Drawing.Size(116, 44);
            this.BTTNEP.TabIndex = 19;
            this.BTTNEP.Text = "Edit Profile";
            this.BTTNEP.UseVisualStyleBackColor = true;
            this.BTTNEP.Click += new System.EventHandler(this.BTTNEP_Click);
            // 
            // LBLMH
            // 
            this.LBLMH.AutoSize = true;
            this.LBLMH.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLMH.Location = new System.Drawing.Point(16, 11);
            this.LBLMH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLMH.Name = "LBLMH";
            this.LBLMH.Size = new System.Drawing.Size(174, 34);
            this.LBLMH.TabIndex = 20;
            this.LBLMH.Text = "Edit Profile";
            // 
            // LSBVP
            // 
            this.LSBVP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LSBVP.FormattingEnabled = true;
            this.LSBVP.ItemHeight = 26;
            this.LSBVP.Location = new System.Drawing.Point(66, 89);
            this.LSBVP.Margin = new System.Windows.Forms.Padding(4);
            this.LSBVP.Name = "LSBVP";
            this.LSBVP.Size = new System.Drawing.Size(900, 56);
            this.LSBVP.TabIndex = 21;
            // 
            // LBLUI
            // 
            this.LBLUI.AutoSize = true;
            this.LBLUI.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLUI.Location = new System.Drawing.Point(61, 59);
            this.LBLUI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLUI.Name = "LBLUI";
            this.LBLUI.Size = new System.Drawing.Size(78, 26);
            this.LBLUI.TabIndex = 22;
            this.LBLUI.Text = "User_id";
            // 
            // LBLName
            // 
            this.LBLName.AutoSize = true;
            this.LBLName.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLName.Location = new System.Drawing.Point(203, 59);
            this.LBLName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLName.Name = "LBLName";
            this.LBLName.Size = new System.Drawing.Size(65, 26);
            this.LBLName.TabIndex = 23;
            this.LBLName.Text = "Name";
            // 
            // LBLRole
            // 
            this.LBLRole.AutoSize = true;
            this.LBLRole.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLRole.Location = new System.Drawing.Point(325, 59);
            this.LBLRole.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLRole.Name = "LBLRole";
            this.LBLRole.Size = new System.Drawing.Size(52, 26);
            this.LBLRole.TabIndex = 24;
            this.LBLRole.Text = "Role";
            // 
            // LBLAge
            // 
            this.LBLAge.AutoSize = true;
            this.LBLAge.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLAge.Location = new System.Drawing.Point(421, 59);
            this.LBLAge.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLAge.Name = "LBLAge";
            this.LBLAge.Size = new System.Drawing.Size(45, 26);
            this.LBLAge.TabIndex = 25;
            this.LBLAge.Text = "Age";
            // 
            // LBLPN
            // 
            this.LBLPN.AutoSize = true;
            this.LBLPN.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLPN.Location = new System.Drawing.Point(549, 59);
            this.LBLPN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLPN.Name = "LBLPN";
            this.LBLPN.Size = new System.Drawing.Size(146, 26);
            this.LBLPN.TabIndex = 26;
            this.LBLPN.Text = "Phone_number";
            // 
            // LBLEmail
            // 
            this.LBLEmail.AutoSize = true;
            this.LBLEmail.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLEmail.Location = new System.Drawing.Point(742, 59);
            this.LBLEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLEmail.Name = "LBLEmail";
            this.LBLEmail.Size = new System.Drawing.Size(61, 26);
            this.LBLEmail.TabIndex = 27;
            this.LBLEmail.Text = "Email";
            // 
            // LBLPassword
            // 
            this.LBLPassword.AutoSize = true;
            this.LBLPassword.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLPassword.Location = new System.Drawing.Point(844, 59);
            this.LBLPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLPassword.Name = "LBLPassword";
            this.LBLPassword.Size = new System.Drawing.Size(97, 26);
            this.LBLPassword.TabIndex = 28;
            this.LBLPassword.Text = "Password";
            // 
            // Edit_Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.LBLPassword);
            this.Controls.Add(this.LBLEmail);
            this.Controls.Add(this.LBLPN);
            this.Controls.Add(this.LBLAge);
            this.Controls.Add(this.LBLRole);
            this.Controls.Add(this.LBLName);
            this.Controls.Add(this.LBLUI);
            this.Controls.Add(this.LSBVP);
            this.Controls.Add(this.LBLMH);
            this.Controls.Add(this.BTTNEP);
            this.Controls.Add(this.BttnExit);
            this.Controls.Add(this.TXTBNI);
            this.Controls.Add(this.lblNI);
            this.Controls.Add(this.CBBEdit);
            this.Controls.Add(this.lblEI);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Edit_Profile";
            this.Text = "Edit_Profile";
            this.Load += new System.EventHandler(this.Edit_Profile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXTBNI;
        private System.Windows.Forms.Label lblNI;
        private System.Windows.Forms.ComboBox CBBEdit;
        private System.Windows.Forms.Label lblEI;
        private System.Windows.Forms.Button BttnExit;
        private System.Windows.Forms.Button BTTNEP;
        private System.Windows.Forms.Label LBLMH;
        private System.Windows.Forms.ListBox LSBVP;
        private System.Windows.Forms.Label LBLUI;
        private System.Windows.Forms.Label LBLName;
        private System.Windows.Forms.Label LBLRole;
        private System.Windows.Forms.Label LBLAge;
        private System.Windows.Forms.Label LBLPN;
        private System.Windows.Forms.Label LBLEmail;
        private System.Windows.Forms.Label LBLPassword;
    }
}