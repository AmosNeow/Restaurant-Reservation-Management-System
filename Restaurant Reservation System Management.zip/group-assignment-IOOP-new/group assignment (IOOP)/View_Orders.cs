﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Collections;


namespace IOOP_assignment
{
    public partial class frmViewOrders : Form
    {

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmChefMenu k = new frmChefMenu();
            Chef_Class.Change_Form(this, k);
        }

        private Chef_Class chef = new Chef_Class(); // Create an instance of Chef_Class
        private int selectedOrderId = -1;


        public frmViewOrders()
        {
            InitializeComponent();
            
            LoadOrders();  // Load orders when the form is initialized

            // Attach event handlers
            lstOrders.SelectedIndexChanged += lstOrders_SelectedIndexChanged;
            btnSave.Click += btnSave_Click;
        }

       



        // Load orders from the database into the ListBox
        private void LoadOrders()
        {
            lstOrders.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            string query = "SELECT Order_Id, Name, Category, Price, Quantity FROM [Order];";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Format order and add it to the ListBox
                            string order = $"{reader["Order_Id"]}: {reader["Name"]} - {reader["Category"]} - RM{reader["Price"]} - Qty: {reader["Quantity"]}";
                            lstOrders.Items.Add(order);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading orders: {ex.Message}");
            }
        }


        private void lstOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if an item is selected
            if (lstOrders.SelectedItem == null)
                return;

            // Reset the radio buttons when a new order is selected
            radInProgress.Checked = false;
            radCompleted.Checked = false;

            // Extract the OrderId from the selected ListBox item
            string selectedOrder = lstOrders.SelectedItem.ToString();
            if (!int.TryParse(selectedOrder.Split(':')[0], out selectedOrderId))
            {
                MessageBox.Show("Invalid order selection.");
                return;
            }

            // Get the current order status and update radio buttons
            string orderStatus = chef.GetOrderStatus(selectedOrderId);
            if (orderStatus == "In Progress")
            {
                radInProgress.Checked = true;
            }
            else if (orderStatus == "Completed")
            {
                radCompleted.Checked = true;
            }
        }

        

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Make sure an order is selected
            if (selectedOrderId == -1)
            {
                MessageBox.Show("Please select an order first.");
                return;
            }

            // Determine the selected status
            string status = "";
            if (radInProgress.Checked)
            {
                status = "In Progress";
                
            }
            else if (radCompleted.Checked)
            {
                status = "Completed";
                
            }            

            // Update the status in the database
            chef.UpdateOrderStatus(selectedOrderId, status);
            MessageBox.Show("Order status updated successfully.");
        }
    }
    
}
