﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Collections;


namespace IOOP_assignment
{
    public partial class frmViewIngredients : Form
    {
        


        public frmViewIngredients()
        {
            InitializeComponent();
            LoadIngredients();
            this.lstMainIngredients.SelectedIndexChanged += new System.EventHandler(this.lstMainIngredients_SelectedIndexChanged);

        }






        private void btnBack_Click(object sender, EventArgs e)
        {
            frmChefMenu n = new frmChefMenu();
            Chef_Class.Change_Form(this, n);
        }

        private void btnEditIngredientList_Click(object sender, EventArgs e)
        {
            frmEditIngredientList p = new frmEditIngredientList();
            Chef_Class.Change_Form(this, p);
        }



        private void LoadIngredients()
        {
            Chef_Class chef = new Chef_Class();
            List<Tuple<int, string, int>> ingredients = chef.GetIngredients(); // Returns List<Tuple<int, string, int>>

            // Clear existing items
            lstMainIngredients.Items.Clear();

            // Populate ListBox with all three fields (Ingredient_Id, Name, and Quantity)
            foreach (var ingredient in ingredients)
            {
                lstMainIngredients.Items.Add($"ID: {ingredient.Item1}, Name: {ingredient.Item2}, Quantity: {ingredient.Item3}");
            }

        }



        private void lstMainIngredients_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Make sure an item is selected
            if (lstMainIngredients.SelectedItem == null)
                return;

            // Get the selected item in ListBox
            string selectedIngredient = lstMainIngredients.SelectedItem.ToString();

            // Extract the Ingredient_Id and Quantity from the selected item
            string[] parts = selectedIngredient.Split(new string[] { ", " }, StringSplitOptions.None);
            int ingredientId = int.Parse(parts[0].Split(':')[1].Trim()); // Extract Ingredient_Id
            int quantity = int.Parse(parts[2].Split(':')[1].Trim()); // Extract Quantity

            // Set the NumericUpDown value to the current quantity of the selected ingredient
            numQuantity.Value = quantity;

            // Store the Ingredient_Id as a Tag or field if needed to access it later
            numQuantity.Tag = ingredientId; // We can use this to access the Ingredient_Id when saving
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Ensure an item is selected in the ListBox
            if (lstMainIngredients.SelectedItem == null)
            {
                MessageBox.Show("Please select an ingredient from the list.");
                return;
            }

            // Get the Ingredient_Id from the NumericUpDown's Tag (stored earlier)
            int ingredientId = (int)numQuantity.Tag;

            // Get the new quantity from NumericUpDown
            int newQuantity = (int)numQuantity.Value;

            // Update the quantity in the database
            UpdateQuantityInDatabase(ingredientId, newQuantity);

            // Optionally, update the ListBox display with the new quantity
            UpdateListBoxItem(ingredientId, newQuantity);
        }

        private void UpdateQuantityInDatabase(int ingredientId, int newQuantity)
        {

            // SQL query to update the quantity
            string query = "UPDATE Ingredient SET Quantity = @Quantity WHERE Ingredient_Id = @IngredientId";

            try
            {
                // Create a new connection to the database
                using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    // Create the command and add parameters
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Quantity", newQuantity);
                    command.Parameters.AddWithValue("@IngredientId", ingredientId);

                    // Open the connection and execute the query
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Quantity updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update the quantity.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void UpdateListBoxItem(int ingredientId, int newQuantity)
        {
            // Find the item in the ListBox based on the Ingredient_Id and update the quantity
            for (int i = 0; i < lstMainIngredients.Items.Count; i++)
            {
                string item = lstMainIngredients.Items[i].ToString();
                string[] parts = item.Split(new string[] { ", " }, StringSplitOptions.None);
                int currentId = int.Parse(parts[0].Split(':')[1].Trim()); // Get the Ingredient_Id from the ListBox item

                if (currentId == ingredientId)
                {
                    // Update the ListBox item with the new quantity
                    lstMainIngredients.Items[i] = $"ID: {ingredientId}, Name: {parts[1].Split(':')[1].Trim()}, Quantity: {newQuantity}";
                    break;
                }
            }
        }







    }
    
}
