﻿namespace group_assignment__IOOP_
{
    partial class AdminCustomerFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminCustomerFeedback));
            this.BackBtn = new System.Windows.Forms.Button();
            this.MessageLabel = new System.Windows.Forms.Label();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.ViewCustomerFeedbackMenu = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listViewCF = new System.Windows.Forms.ListView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Location = new System.Drawing.Point(474, 334);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(198, 35);
            this.BackBtn.TabIndex = 40;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-12, 402);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 39;
            this.MessageLabel.Text = "      Luna : Here is all customer feedbacks.";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(50, 95);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 38;
            // 
            // ViewCustomerFeedbackMenu
            // 
            this.ViewCustomerFeedbackMenu.AutoSize = true;
            this.ViewCustomerFeedbackMenu.BackColor = System.Drawing.SystemColors.Highlight;
            this.ViewCustomerFeedbackMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ViewCustomerFeedbackMenu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewCustomerFeedbackMenu.Location = new System.Drawing.Point(-12, -2);
            this.ViewCustomerFeedbackMenu.MinimumSize = new System.Drawing.Size(820, 50);
            this.ViewCustomerFeedbackMenu.Name = "ViewCustomerFeedbackMenu";
            this.ViewCustomerFeedbackMenu.Size = new System.Drawing.Size(820, 50);
            this.ViewCustomerFeedbackMenu.TabIndex = 36;
            this.ViewCustomerFeedbackMenu.Text = "   View Customer Feedback";
            this.ViewCustomerFeedbackMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 454);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // listViewCF
            // 
            this.listViewCF.FullRowSelect = true;
            this.listViewCF.GridLines = true;
            this.listViewCF.HideSelection = false;
            this.listViewCF.Location = new System.Drawing.Point(360, 95);
            this.listViewCF.MultiSelect = false;
            this.listViewCF.Name = "listViewCF";
            this.listViewCF.Size = new System.Drawing.Size(398, 217);
            this.listViewCF.TabIndex = 42;
            this.listViewCF.UseCompatibleStateImageBehavior = false;
            this.listViewCF.View = System.Windows.Forms.View.Details;
            // 
            // AdminCustomerFeedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listViewCF);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.ViewCustomerFeedbackMenu);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminCustomerFeedback";
            this.Text = "AdminCustomerFeedback";
            this.Load += new System.EventHandler(this.AdminCustomerFeedback_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.Label ViewCustomerFeedbackMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewCF;
    }
}