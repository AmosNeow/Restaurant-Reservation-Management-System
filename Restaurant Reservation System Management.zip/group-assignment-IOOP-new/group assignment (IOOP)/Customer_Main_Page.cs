﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_Main_Page : Form
    {
        public Customer_Main_Page()
        {
            InitializeComponent();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            Customer_Order obj1 = new Customer_Order();
            obj1.Show();
            this.Hide();
        }

        private void btnOrderStatus_Click(object sender, EventArgs e)
        {
            Customer_OrderStatus obj1 = new Customer_OrderStatus();
            obj1.Show();
            this.Hide();
        }

        private void btnOrderFeedback_Click(object sender, EventArgs e)
        {
            Customer_OrderFeedback obj1 = new Customer_OrderFeedback();
            obj1.Show();
            this.Hide();
        }

        private void btnReservation_Click(object sender, EventArgs e)
        {
           Customer_Reservation obj1 = new Customer_Reservation();
           obj1.Show();
           this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnReservationStatus_Click(object sender, EventArgs e)
        {
            Customer_ReservationStatus obj1 = new Customer_ReservationStatus();
           obj1.Show();
            this.Hide();
        }

        private void btnReservationFeedback_Click(object sender, EventArgs e)
        {
            Customer_ReservationFeedback obj1 = new Customer_ReservationFeedback();
            obj1.Show();
            this.Hide();
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e)
        {
            Customer_UpdateProfile obj1 = new Customer_UpdateProfile();
            obj1.Show();
            this.Hide();
        }

        private void LogOutBtn_Click(object sender, EventArgs e)
        {
            LogIn l = new LogIn();
            l.Show();
            this.Hide();
        }
    }
}
