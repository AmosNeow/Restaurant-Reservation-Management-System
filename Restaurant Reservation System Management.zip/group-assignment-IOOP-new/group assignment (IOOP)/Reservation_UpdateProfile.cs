﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;
using static System.Net.Mime.MediaTypeNames;

namespace group_assignment__IOOP_
{
    public partial class Reservation_UpdateProfile : Form
    {
        int userId = User.LoggedInUser.UserId;
        public Reservation_UpdateProfile()
        {
            InitializeComponent();
        }

        private void Reservation_UpdateProfile_Load(object sender, EventArgs e)
        {
            int userId = User.LoggedInUser.UserId;
            ViewProfilereservaton(userId);

            txtName.Enabled = false;
            txtAge.Enabled = false;
            txtPhoneNumber.Enabled = false;
            txtPassword.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
        
            
         int userId = User.LoggedInUser.UserId;
         string newName = txtName.Text;
         int newAge = int.Parse(txtAge.Text);
         string newPhone = txtPhoneNumber.Text;
         string newPassword = txtPassword.Text;


         myProfile.UpdateProfile(userId, newName, newAge, newPhone, newPassword);
         ViewProfilereservaton(userId);

            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            reservation_coordinator q = new reservation_coordinator();
            q.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private string ViewProfilereservaton(int userId)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
            {
                string query = "SELECT Name, Age, Phone_number, Password FROM Users WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    conn.Open(); 

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) 
                        {
                            txtName.Text = reader["Name"].ToString();
                            txtAge.Text = $"{reader["Age"]}";
                            txtPhoneNumber.Text = $"{reader["Phone_number"]}";
                            txtPassword.Text = $"{reader["Password"]}";
                        }
                    }
                }
            }
            return "User not found."; 
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            txtName.Enabled = (chbEdit.Checked);
            txtAge.Enabled = (chbEdit.Checked);
            txtPhoneNumber.Enabled =(chbEdit.Checked);
            txtPassword.Enabled = (chbEdit.Checked);
        }
    }
}
