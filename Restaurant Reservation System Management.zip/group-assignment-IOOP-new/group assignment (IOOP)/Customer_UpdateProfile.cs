﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using group_assignment__IOOP_;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_UpdateProfile : Form
    {
        int userId = User.LoggedInUser.UserId;
        public Customer_UpdateProfile()
        {
            InitializeComponent();
        }

        private void btnViewProfile_Click(object sender, EventArgs e)
        {
            int userId = User.LoggedInUser.UserId;
            lblProfileDetails.Text = myProfile.ViewProfile(userId);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtName.Text) && !string.IsNullOrWhiteSpace(numAge.Text) &&
                !string.IsNullOrWhiteSpace(txtPhoneNumber.Text) && !string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                int userId = User.LoggedInUser.UserId;
                string newName = txtName.Text;
                int newAge = int.Parse(numAge.Text);
                string newPhone = txtPhoneNumber.Text;
                string newPassword = txtPassword.Text;


                myProfile.UpdateProfile(userId, newName, newAge, newPhone, newPassword);

                txtName.Clear();
                numAge.Value = 0;
                txtPhoneNumber.Clear();
                txtPassword.Clear();
                lblProfileDetails.Text = "";
            }
            else { MessageBox.Show("Please fill all the details."); }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }
    }
}
