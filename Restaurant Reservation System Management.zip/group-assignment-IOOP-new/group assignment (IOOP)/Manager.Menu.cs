﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class Manage_Menu : Form
    {
        DatabaseMenu dbMenu = new DatabaseMenu();
        public Manage_Menu()
        {
            InitializeComponent();
        }

        private void Manage_Menu_Load(object sender, EventArgs e)
        {
            LoadEntireTable();
        }

        private void LoadEntireTable()
        {
            LSBMenu.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            // Step 2: Query the database
            string query = "SELECT * FROM Menu";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Step 3: Execute the command
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    // Step 4: Load data into ListBox

                    while (reader.Read())
                    {
                        List<string> rowData = new List<string>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            rowData.Add(reader.GetValue(i).ToString().PadRight(20)); // Adjust width dynamically
                        }

                        LSBMenu.Items.Add(string.Join(" ", rowData));
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void BttnExit_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Main_Page form2 = new Main_Page();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void LSBMenu_SelectedIndexChange(object sender, EventArgs e)
        {

        }

        private void bttnAM_Click(object sender, EventArgs e)
        {
            MenuItem additem = new MenuItem(
            TXTBNF.Text,
            TXTBCategory.Text,
            float.Parse(TXTBPrice.Text));

            bool success = dbMenu.AddMenuItem(additem);

            // Provide feedback to the user
            if (success)
            {
                MessageBox.Show("Menu item added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add menu item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            LoadEntireTable();
        }

        private void bttnDM_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TXTBDR.Text))
            {
                MessageBox.Show("Please enter the menu item ID.");
                return;
            }

            if (!int.TryParse(TXTBDR.Text, out int Food_id))
            {
                MessageBox.Show("Invalid ID format. Please enter a numeric value.");
                return;
            }

            if (dbMenu.DeleteMenuItem(Food_id))
            {
                MessageBox.Show("Menu item deleted successfully!");
            }
            else
            {
                MessageBox.Show("Deletion failed. Make sure the ID exists.");
            }
            LoadEntireTable();
        }

        private void bttnEM_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TXTBFN.Text) || string.IsNullOrWhiteSpace(TXTBNP.Text))
            {
                MessageBox.Show("Please enter the food name and price.");
                return;
            }

            if (!float.TryParse(TXTBNP.Text, out float newPrice))
            {
                MessageBox.Show("Invalid price format.");
                return;
            }

            if (dbMenu.EditMenuItemPrice(TXTBFN.Text, newPrice))
            {
                MessageBox.Show("Price updated successfully!");
            }
            else
            {
                MessageBox.Show("Update failed. Make sure the food name exists.");
            }
            LoadEntireTable();
        }

        private void LSBMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}