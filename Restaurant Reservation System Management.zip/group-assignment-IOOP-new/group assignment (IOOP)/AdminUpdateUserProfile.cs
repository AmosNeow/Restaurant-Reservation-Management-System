﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class AdminUpdateUserProfile: Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminUpdateUserProfile()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminManageUserProfile manageuserprofile = new AdminManageUserProfile();
            manageuserprofile.Show();
            this.Close();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(IDComboBox.Text) ||
                string.IsNullOrWhiteSpace(NameTxt.Text) ||
                string.IsNullOrWhiteSpace(RoleComboBox.Text) ||
                string.IsNullOrWhiteSpace(AgeTxt.Text) ||
                string.IsNullOrWhiteSpace(PhoneTxt.Text) ||
                string.IsNullOrWhiteSpace(EmailTxt.Text) ||
                string.IsNullOrWhiteSpace(PasswordTxt.Text))
                {
                    MessageBox.Show("All fields must be filled out before saving.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // return to stop the function
                }
                else
                {
                    int userid = Convert.ToInt32(IDComboBox.SelectedValue);
                    string username = NameTxt.Text;
                    string role = RoleComboBox.Text;
                    int age = Convert.ToInt32(AgeTxt.Text);
                    string phone = PhoneTxt.Text;
                    string email = EmailTxt.Text;
                    string password = PasswordTxt.Text;
                    UserProfile up = new UserProfile(userid, username, password, email, phone, age, role);
                    up.UpdateUP();
                }  
            }
            catch (FormatException)
            {
                MessageBox.Show("Age must be integer. Please try again.");
            }

        }

        private void RoleComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void UpdateUserProfileMenu_Click(object sender, EventArgs e)
        {

        }

        private void ImageLabel_Click(object sender, EventArgs e)
        {

        }

        private void MessageLabel_Click(object sender, EventArgs e)
        {

        }

        private void AgeTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void AgeLabel_Click(object sender, EventArgs e)
        {

        }

        private void PhoneTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void RoleLabel_Click(object sender, EventArgs e)
        {

        }

        private void NameTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void PhoneLabel_Click(object sender, EventArgs e)
        {

        }

        private void IDcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void EmailLabel_Click(object sender, EventArgs e)
        {

        }

        private void PasswordTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void EmailTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void AdminUpdateUserProfile_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT User_Id FROM Users", con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            IDComboBox.DataSource = dt;
            IDComboBox.DisplayMember = "User_Id";
            IDComboBox.ValueMember = "User_Id";
        }

        private void IDLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
