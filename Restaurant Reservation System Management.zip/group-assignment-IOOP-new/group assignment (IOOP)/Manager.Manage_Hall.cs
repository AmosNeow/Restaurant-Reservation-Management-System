﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class Manage_Hall : Form
    {
        public Manage_Hall()
        {
            InitializeComponent();
        }

        DatabaseHallDetails dbHall = new DatabaseHallDetails();

        private void Manage_Hall_Load(object sender, EventArgs e)
        {
            Loadtable();
        }


        private void Loadtable()
        {
            LSBHall.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            // Step 2: Query the database
            string query = "SELECT * FROM Hall_Details";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Step 3: Execute the command
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    // Step 4: Load data into ListBox

                    while (reader.Read())
                    {
                        List<string> rowData = new List<string>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            rowData.Add(reader.GetValue(i).ToString().PadRight(20)); // Adjust width dynamically
                        }

                        LSBHall.Items.Add(string.Join(" ", rowData));
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BttnExit_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Main_Page form2 = new Main_Page();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void LSBHall_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bttnAH_Click(object sender, EventArgs e)
        {
            HallDetails addHall = new HallDetails(
            int.Parse(TXTBCapacity.Text),
           int.Parse(TXTBPrice.Text));

            bool success = dbHall.AddHallDetails(addHall);

            // Provide feedback to the user
            if (success)
            {
                MessageBox.Show("Menu item added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to add menu item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Loadtable();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bttnDH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TXTBDH.Text))
            {
                MessageBox.Show("Please enter the menu item ID.");
                return;
            }

            if (!int.TryParse(TXTBDH.Text, out int Hall_id))
            {
                MessageBox.Show("Invalid ID format. Please enter a numeric value.");
                return;
            }

            if (dbHall.DeleteHall(Hall_id))
            {
                MessageBox.Show("Menu item deleted successfully!");
            }
            else
            {
                MessageBox.Show("Deletion failed. Make sure the ID exists.");
            }
            Loadtable();
        }

        private void bttnEH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TXTBHallID.Text) || string.IsNullOrWhiteSpace(TXTBNC.Text) || string.IsNullOrWhiteSpace(TXTBNP.Text))
            {
                MessageBox.Show("Please enter the hall ID, new capacity and new price.");
                return;
            }

            if (!int.TryParse(TXTBHallID.Text, out int Hall_id))
            {
                MessageBox.Show("Invalid hall ID format.");
                return;
            }

            if (!int.TryParse(TXTBNC.Text, out int newCapacity) || !int.TryParse(TXTBNP.Text, out int newPrice))
            {
                MessageBox.Show("Invalid price or capacity format.");
                return;
            }

            if (dbHall.UpdateHallCapacityPrice(Hall_id, newCapacity,  newPrice))
            {
                MessageBox.Show("Hall details updated successfully!");
            }
            else
            {
                MessageBox.Show("Update failed. Make sure the hall ID exists.");
            }

            Loadtable();
        }

        private void lbl_Hallid_Click(object sender, EventArgs e)
        {

        }

        private void lbl_price_Click(object sender, EventArgs e)
        {

        }
    }
}
