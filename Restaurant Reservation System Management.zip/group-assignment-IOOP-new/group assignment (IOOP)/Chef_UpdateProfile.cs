﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using group_assignment__IOOP_;
using IOOP_assignment;


namespace group_assignment__IOOP_
{
    public partial class Chef_UpdateProfile : Form
    {
        int userId = User.LoggedInUser.UserId;
        public Chef_UpdateProfile()
        {
            InitializeComponent();
        }
                     
                

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            frmChefMenu k = new frmChefMenu();
            Chef_Class.Change_Form(this, k);
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtName.Text) && !string.IsNullOrWhiteSpace(numAge.Text) &&
                !string.IsNullOrWhiteSpace(txtPhoneNumber.Text) && !string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                int userId = User.LoggedInUser.UserId;
                string newName = txtName.Text;
                int newAge = int.Parse(numAge.Text);
                string newPhone = txtPhoneNumber.Text;
                string newPassword = txtPassword.Text;


                myProfile.UpdateProfile(userId, newName, newAge, newPhone, newPassword);

                txtName.Clear();
                numAge.Value = 0;
                txtPhoneNumber.Clear();
                txtPassword.Clear();
                lblProfileDetails.Text = "";
            }
            else { MessageBox.Show("Please fill all the details."); }
        }

        private void btnViewProfile_Click_1(object sender, EventArgs e)
        {
            int userId = User.LoggedInUser.UserId;
            lblProfileDetails.Text = myProfile.ViewProfile(userId);
        }
    }
}
