﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using group_assignment__IOOP_;
using IOOP_assignment;

namespace MOK_IOOPassignment
{
    public partial class LogIn : Form
    {
       
        public LogIn()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            User user = User.Login(txtEmail.Text, txtPassword.Text);

            if (user != null)
            {
                MessageBox.Show($"Welcome, {user.Name}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (user.Role == "Customer")
                {
                    new Customer_Main_Page().Show();
                }
                if (user.Role == "Admin")
                {
                    new AdminHomePage().Show();
                }
                if (user.Role == "Chef")
                {
                    new frmChefMenu().Show();
                }
                if (user.Role == "Reservation Coordinator")
                {
                    reservation_coordinator r = new reservation_coordinator();
                    r.Show();




                }
                if (user.Role == "Manager")
                {
                    Main_Page M = new Main_Page();
                    M.Show();
                }


                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid email or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignIn obj1 = new SignIn();
            obj1.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
