﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class AdminHomePage: Form
    {
        public AdminHomePage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogIn l = new LogIn();  
            l.Show();
            this.Hide();
        }

        private void ManageUserProfileBtn_Click(object sender, EventArgs e)
        {
            AdminManageUserProfile manageuserprofile = new AdminManageUserProfile();
            manageuserprofile.Show();
            this.Hide();
        }

        private void ViewSalesReportBtn_Click(object sender, EventArgs e)
        {
            AdminViewSalesReport viewsalesreport = new AdminViewSalesReport();
            viewsalesreport.Show();
            this.Hide();
        }

        private void ViewCustomerFeedbackBtn_Click(object sender, EventArgs e)
        {
            AdminCustomerFeedback customerfeedback = new AdminCustomerFeedback();
            customerfeedback.Show();
            this.Hide();
        }

        private void UpdateOwnProfileBtn_Click(object sender, EventArgs e)
        {
            AdminUpdateOwnProfile updateownprofile = new AdminUpdateOwnProfile();
            updateownprofile.Show();
            this.Hide();
        }

        private void AdminHomePage_Load(object sender, EventArgs e)
        {

        }

        private void ViewReservationFeedbackBtn_Click(object sender, EventArgs e)
        {
            AdminViewReservationFeedback viewreservationfeedback = new AdminViewReservationFeedback();
            viewreservationfeedback.Show();
            this.Hide();
        }
    }
}
