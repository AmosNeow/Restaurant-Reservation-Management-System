﻿namespace group_assignment__IOOP_
{
    partial class AdminHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminHomePage));
            this.MessageLabel = new System.Windows.Forms.Label();
            this.UpdateOwnProfileBtn = new System.Windows.Forms.Button();
            this.ViewCustomerFeedbackBtn = new System.Windows.Forms.Button();
            this.ViewSalesReportBtn = new System.Windows.Forms.Button();
            this.ManageUserProfileBtn = new System.Windows.Forms.Button();
            this.LogOutBtn = new System.Windows.Forms.Button();
            this.AdminMenuLabel = new System.Windows.Forms.Label();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ViewReservationFeedbackBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-10, 400);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 30;
            this.MessageLabel.Text = "    Luna : Welcome to Admin Menu. How may i can help you ?";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UpdateOwnProfileBtn
            // 
            this.UpdateOwnProfileBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UpdateOwnProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UpdateOwnProfileBtn.Location = new System.Drawing.Point(495, 327);
            this.UpdateOwnProfileBtn.Name = "UpdateOwnProfileBtn";
            this.UpdateOwnProfileBtn.Size = new System.Drawing.Size(198, 35);
            this.UpdateOwnProfileBtn.TabIndex = 29;
            this.UpdateOwnProfileBtn.Text = "Update Own Profile";
            this.UpdateOwnProfileBtn.UseVisualStyleBackColor = false;
            this.UpdateOwnProfileBtn.Click += new System.EventHandler(this.UpdateOwnProfileBtn_Click);
            // 
            // ViewCustomerFeedbackBtn
            // 
            this.ViewCustomerFeedbackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ViewCustomerFeedbackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ViewCustomerFeedbackBtn.Location = new System.Drawing.Point(495, 201);
            this.ViewCustomerFeedbackBtn.Name = "ViewCustomerFeedbackBtn";
            this.ViewCustomerFeedbackBtn.Size = new System.Drawing.Size(198, 35);
            this.ViewCustomerFeedbackBtn.TabIndex = 28;
            this.ViewCustomerFeedbackBtn.Text = "View Customer Feedback";
            this.ViewCustomerFeedbackBtn.UseVisualStyleBackColor = false;
            this.ViewCustomerFeedbackBtn.Click += new System.EventHandler(this.ViewCustomerFeedbackBtn_Click);
            // 
            // ViewSalesReportBtn
            // 
            this.ViewSalesReportBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ViewSalesReportBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ViewSalesReportBtn.Location = new System.Drawing.Point(495, 132);
            this.ViewSalesReportBtn.Name = "ViewSalesReportBtn";
            this.ViewSalesReportBtn.Size = new System.Drawing.Size(198, 35);
            this.ViewSalesReportBtn.TabIndex = 27;
            this.ViewSalesReportBtn.Text = "View Sales Report";
            this.ViewSalesReportBtn.UseVisualStyleBackColor = false;
            this.ViewSalesReportBtn.Click += new System.EventHandler(this.ViewSalesReportBtn_Click);
            // 
            // ManageUserProfileBtn
            // 
            this.ManageUserProfileBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ManageUserProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ManageUserProfileBtn.Location = new System.Drawing.Point(495, 70);
            this.ManageUserProfileBtn.Name = "ManageUserProfileBtn";
            this.ManageUserProfileBtn.Size = new System.Drawing.Size(198, 35);
            this.ManageUserProfileBtn.TabIndex = 26;
            this.ManageUserProfileBtn.Text = "Manage User Profile";
            this.ManageUserProfileBtn.UseVisualStyleBackColor = false;
            this.ManageUserProfileBtn.Click += new System.EventHandler(this.ManageUserProfileBtn_Click);
            // 
            // LogOutBtn
            // 
            this.LogOutBtn.Location = new System.Drawing.Point(703, 4);
            this.LogOutBtn.Name = "LogOutBtn";
            this.LogOutBtn.Size = new System.Drawing.Size(84, 37);
            this.LogOutBtn.TabIndex = 25;
            this.LogOutBtn.Text = "Log Out";
            this.LogOutBtn.UseVisualStyleBackColor = true;
            this.LogOutBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // AdminMenuLabel
            // 
            this.AdminMenuLabel.AutoSize = true;
            this.AdminMenuLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.AdminMenuLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.AdminMenuLabel.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminMenuLabel.Location = new System.Drawing.Point(-10, -3);
            this.AdminMenuLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.AdminMenuLabel.Name = "AdminMenuLabel";
            this.AdminMenuLabel.Size = new System.Drawing.Size(820, 50);
            this.AdminMenuLabel.TabIndex = 24;
            this.AdminMenuLabel.Text = "  Admin Home Page";
            this.AdminMenuLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(85, 98);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 31;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-10, -9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(820, 468);
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            // 
            // ViewReservationFeedbackBtn
            // 
            this.ViewReservationFeedbackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ViewReservationFeedbackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ViewReservationFeedbackBtn.Location = new System.Drawing.Point(495, 264);
            this.ViewReservationFeedbackBtn.Name = "ViewReservationFeedbackBtn";
            this.ViewReservationFeedbackBtn.Size = new System.Drawing.Size(198, 35);
            this.ViewReservationFeedbackBtn.TabIndex = 33;
            this.ViewReservationFeedbackBtn.Text = "View Reservation Feedback";
            this.ViewReservationFeedbackBtn.UseVisualStyleBackColor = false;
            this.ViewReservationFeedbackBtn.Click += new System.EventHandler(this.ViewReservationFeedbackBtn_Click);
            // 
            // AdminHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ViewReservationFeedbackBtn);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.UpdateOwnProfileBtn);
            this.Controls.Add(this.ViewCustomerFeedbackBtn);
            this.Controls.Add(this.ViewSalesReportBtn);
            this.Controls.Add(this.ManageUserProfileBtn);
            this.Controls.Add(this.LogOutBtn);
            this.Controls.Add(this.AdminMenuLabel);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminHomePage";
            this.Text = "AdminHomePage";
            this.Load += new System.EventHandler(this.AdminHomePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Button UpdateOwnProfileBtn;
        private System.Windows.Forms.Button ViewCustomerFeedbackBtn;
        private System.Windows.Forms.Button ViewSalesReportBtn;
        private System.Windows.Forms.Button ManageUserProfileBtn;
        private System.Windows.Forms.Button LogOutBtn;
        private System.Windows.Forms.Label AdminMenuLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button ViewReservationFeedbackBtn;
    }
}