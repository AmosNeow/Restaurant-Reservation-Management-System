﻿namespace IOOP_assignment
{
    partial class frmEditIngredientList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditIngredientList));
            this.background = new System.Windows.Forms.PictureBox();
            this.lblEditIngredientList = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lstIngredient = new System.Windows.Forms.ListBox();
            this.lblNewIngredientName = new System.Windows.Forms.Label();
            this.lblNewIngredientQuantity = new System.Windows.Forms.Label();
            this.txtNewIngredientName = new System.Windows.Forms.TextBox();
            this.numNewIngredient = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.cmbDeleteIngredient = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNewIngredient)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // background
            // 
            this.background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background.Image = ((System.Drawing.Image)(resources.GetObject("background.Image")));
            this.background.Location = new System.Drawing.Point(0, 0);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(1379, 635);
            this.background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background.TabIndex = 0;
            this.background.TabStop = false;
            // 
            // lblEditIngredientList
            // 
            this.lblEditIngredientList.AutoSize = true;
            this.lblEditIngredientList.Font = new System.Drawing.Font("MV Boli", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditIngredientList.Location = new System.Drawing.Point(50, 48);
            this.lblEditIngredientList.Name = "lblEditIngredientList";
            this.lblEditIngredientList.Size = new System.Drawing.Size(789, 105);
            this.lblEditIngredientList.TabIndex = 1;
            this.lblEditIngredientList.Text = "Edit Ingredient List";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(1204, 531);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(114, 65);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lstIngredient
            // 
            this.lstIngredient.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstIngredient.FormattingEnabled = true;
            this.lstIngredient.ItemHeight = 40;
            this.lstIngredient.Location = new System.Drawing.Point(56, 205);
            this.lstIngredient.Name = "lstIngredient";
            this.lstIngredient.Size = new System.Drawing.Size(508, 324);
            this.lstIngredient.TabIndex = 4;
            // 
            // lblNewIngredientName
            // 
            this.lblNewIngredientName.AutoSize = true;
            this.lblNewIngredientName.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewIngredientName.Location = new System.Drawing.Point(669, 296);
            this.lblNewIngredientName.Name = "lblNewIngredientName";
            this.lblNewIngredientName.Size = new System.Drawing.Size(97, 40);
            this.lblNewIngredientName.TabIndex = 6;
            this.lblNewIngredientName.Text = "Name";
            // 
            // lblNewIngredientQuantity
            // 
            this.lblNewIngredientQuantity.AutoSize = true;
            this.lblNewIngredientQuantity.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewIngredientQuantity.Location = new System.Drawing.Point(669, 360);
            this.lblNewIngredientQuantity.Name = "lblNewIngredientQuantity";
            this.lblNewIngredientQuantity.Size = new System.Drawing.Size(143, 40);
            this.lblNewIngredientQuantity.TabIndex = 7;
            this.lblNewIngredientQuantity.Text = "Quantity";
            // 
            // txtNewIngredientName
            // 
            this.txtNewIngredientName.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewIngredientName.Location = new System.Drawing.Point(834, 291);
            this.txtNewIngredientName.Name = "txtNewIngredientName";
            this.txtNewIngredientName.Size = new System.Drawing.Size(100, 56);
            this.txtNewIngredientName.TabIndex = 8;
            // 
            // numNewIngredient
            // 
            this.numNewIngredient.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numNewIngredient.Location = new System.Drawing.Point(834, 355);
            this.numNewIngredient.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.numNewIngredient.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numNewIngredient.Name = "numNewIngredient";
            this.numNewIngredient.Size = new System.Drawing.Size(120, 56);
            this.numNewIngredient.TabIndex = 9;
            this.numNewIngredient.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(638, 220);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(336, 268);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add New Ingredient";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(196, 197);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(114, 65);
            this.btnAdd.TabIndex = 14;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDelete);
            this.groupBox2.Controls.Add(this.cmbDeleteIngredient);
            this.groupBox2.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(1009, 220);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(319, 268);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Delete Ingredient and it\'s Quantity";
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(174, 182);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(126, 65);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // cmbDeleteIngredient
            // 
            this.cmbDeleteIngredient.FormattingEnabled = true;
            this.cmbDeleteIngredient.Location = new System.Drawing.Point(26, 89);
            this.cmbDeleteIngredient.Name = "cmbDeleteIngredient";
            this.cmbDeleteIngredient.Size = new System.Drawing.Size(121, 48);
            this.cmbDeleteIngredient.TabIndex = 0;
            // 
            // frmEditIngredientList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1379, 635);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.numNewIngredient);
            this.Controls.Add(this.txtNewIngredientName);
            this.Controls.Add(this.lblNewIngredientQuantity);
            this.Controls.Add(this.lblNewIngredientName);
            this.Controls.Add(this.lstIngredient);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblEditIngredientList);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.background);
            this.Name = "frmEditIngredientList";
            this.Text = "Edit_Ingredient_List";
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNewIngredient)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox background;
        private System.Windows.Forms.Label lblEditIngredientList;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ListBox lstIngredient;
        private System.Windows.Forms.Label lblNewIngredientName;
        private System.Windows.Forms.Label lblNewIngredientQuantity;
        private System.Windows.Forms.TextBox txtNewIngredientName;
        private System.Windows.Forms.NumericUpDown numNewIngredient;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbDeleteIngredient;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
    }
}