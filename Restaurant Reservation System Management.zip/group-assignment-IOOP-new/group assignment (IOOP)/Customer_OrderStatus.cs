﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_OrderStatus : Form
    {
        public Customer_OrderStatus()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }

        private void btnViewStatus_Click(object sender, EventArgs e)
        {
            int userId = User.LoggedInUser.UserId;
            txtOrderDetails.Text = OrderItem.ViewOrderDetails(userId);

            lblOrderStatus.Text = OrderItem.ViewOrderStatus(userId);
        }
    }
}
