﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    internal class myProfile
    {
        private int userId;
        private string name;
        private int age;
        private string phoneNumber;
        private string password;

        private static readonly string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

      
        public myProfile(int userId, string name, int age, string phoneNumber, string password)
        {
            this.userId = userId;
            this.name = name;
            this.age = age;
            this.phoneNumber = phoneNumber;
            this.password = password;
        }

        // Method to view profile details and display them in labels
        public static string ViewProfile(int userId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT Name, Age, Phone_number, Password FROM Users WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) // If user data is found
                        {
                            return $"Name: {reader["Name"]}\n" +
                                   $"Age: {reader["Age"]}\n" +
                                   $"Phone: {reader["Phone_number"]}\n" +
                                   $"Password: {reader["Password"]}";
                        }
                    }
                }
            }
            return "User not found."; // Return message if no user is found
        }

        // Method to update profile details
        public static void UpdateProfile(int userId, string newName, int newAge, string newPhone, string newPassword)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Users SET Name = @Name, Age = @Age, Phone_number = @Phone, Password = @Password WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@Name", newName);
                    cmd.Parameters.AddWithValue("@Age", newAge);
                    cmd.Parameters.AddWithValue("@Phone", newPhone);
                    cmd.Parameters.AddWithValue("@Password", newPassword);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Update failed. User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }
    }
}
