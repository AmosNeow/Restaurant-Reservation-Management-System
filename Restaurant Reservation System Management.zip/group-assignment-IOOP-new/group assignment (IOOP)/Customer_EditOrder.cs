﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class EditOrderForm : Form
    {
        private string _itemName;
        private int _itemQuantity;

        public EditOrderForm(string itemName, int quantity)
        {
            InitializeComponent();
            _itemName = itemName;
            _itemQuantity = quantity;

            lblItemName.Text = _itemName;
            numQuantity.Value = _itemQuantity;
        }

        public int GetUpdatedQuantity()
        {
            return _itemQuantity;
        }

        private void btnSaveEdit_Click(object sender, EventArgs e)
        {
            _itemQuantity = (int)numQuantity.Value; // Save updated quantity
            this.DialogResult = DialogResult.OK;    // Marks the edit as successful
            this.Close(); // Close the form
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
