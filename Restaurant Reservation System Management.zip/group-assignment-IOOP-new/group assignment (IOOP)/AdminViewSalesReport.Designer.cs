﻿namespace group_assignment__IOOP_
{
    partial class AdminViewSalesReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminViewSalesReport));
            this.ViewSalesReportMenu = new System.Windows.Forms.Label();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.MessageLabel = new System.Windows.Forms.Label();
            this.BackBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listViewSR = new System.Windows.Forms.ListView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewSalesReportMenu
            // 
            this.ViewSalesReportMenu.AutoSize = true;
            this.ViewSalesReportMenu.BackColor = System.Drawing.SystemColors.Highlight;
            this.ViewSalesReportMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ViewSalesReportMenu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewSalesReportMenu.Location = new System.Drawing.Point(-12, -2);
            this.ViewSalesReportMenu.MinimumSize = new System.Drawing.Size(820, 50);
            this.ViewSalesReportMenu.Name = "ViewSalesReportMenu";
            this.ViewSalesReportMenu.Size = new System.Drawing.Size(820, 50);
            this.ViewSalesReportMenu.TabIndex = 5;
            this.ViewSalesReportMenu.Text = "   View Sales Report";
            this.ViewSalesReportMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(50, 95);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 33;
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-12, 402);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 34;
            this.MessageLabel.Text = "     Luna : Here is the sales report.";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Location = new System.Drawing.Point(457, 334);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(198, 35);
            this.BackBtn.TabIndex = 35;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 454);
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // listViewSR
            // 
            this.listViewSR.FullRowSelect = true;
            this.listViewSR.GridLines = true;
            this.listViewSR.HideSelection = false;
            this.listViewSR.Location = new System.Drawing.Point(387, 95);
            this.listViewSR.MultiSelect = false;
            this.listViewSR.Name = "listViewSR";
            this.listViewSR.Size = new System.Drawing.Size(361, 209);
            this.listViewSR.TabIndex = 43;
            this.listViewSR.UseCompatibleStateImageBehavior = false;
            this.listViewSR.View = System.Windows.Forms.View.Details;
            // 
            // AdminViewSalesReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listViewSR);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.ViewSalesReportMenu);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminViewSalesReport";
            this.Text = "AdminViewSalesReport";
            this.Load += new System.EventHandler(this.AdminViewSalesReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ViewSalesReportMenu;
        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewSR;
    }
}