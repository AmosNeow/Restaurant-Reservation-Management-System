﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Main_Page : Form
    {
        public Main_Page()
        {
            InitializeComponent();
        }

        private void Main_Page_Load(object sender, EventArgs e)
        {

        }

        private void BttnMM_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Manage_Menu form2 = new Manage_Menu();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();


        }

        private void Panel_1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BttnMH_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Manage_Hall form2 = new Manage_Hall();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void BttnVHR_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            View_Hall form2 = new View_Hall();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void BttnMP_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Edit_Profile form2 = new Edit_Profile();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void LogOutBtn_Click(object sender, EventArgs e)
        {
            LogIn l = new LogIn();
            l.Show();
            this.Hide();
        }
    }
}
