﻿namespace IOOP_assignment
{
    partial class frmViewOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewOrders));
            this.background = new System.Windows.Forms.PictureBox();
            this.lblViewOrders = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lstOrders = new System.Windows.Forms.ListBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.radInProgress = new System.Windows.Forms.RadioButton();
            this.radCompleted = new System.Windows.Forms.RadioButton();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            this.SuspendLayout();
            // 
            // background
            // 
            this.background.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background.Image = ((System.Drawing.Image)(resources.GetObject("background.Image")));
            this.background.Location = new System.Drawing.Point(0, 0);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(1498, 651);
            this.background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background.TabIndex = 0;
            this.background.TabStop = false;
            // 
            // lblViewOrders
            // 
            this.lblViewOrders.AutoSize = true;
            this.lblViewOrders.Font = new System.Drawing.Font("MV Boli", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewOrders.Location = new System.Drawing.Point(61, 51);
            this.lblViewOrders.Name = "lblViewOrders";
            this.lblViewOrders.Size = new System.Drawing.Size(497, 105);
            this.lblViewOrders.TabIndex = 1;
            this.lblViewOrders.Text = "View Orders";
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(1204, 544);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(103, 63);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lstOrders
            // 
            this.lstOrders.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOrders.FormattingEnabled = true;
            this.lstOrders.ItemHeight = 40;
            this.lstOrders.Location = new System.Drawing.Point(31, 211);
            this.lstOrders.Name = "lstOrders";
            this.lstOrders.Size = new System.Drawing.Size(1087, 364);
            this.lstOrders.TabIndex = 3;
            this.lstOrders.SelectedIndexChanged += new System.EventHandler(this.lstOrders_SelectedIndexChanged);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("MV Boli", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(1180, 195);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(222, 79);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "Status";
            // 
            // radInProgress
            // 
            this.radInProgress.AutoSize = true;
            this.radInProgress.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radInProgress.Location = new System.Drawing.Point(1187, 312);
            this.radInProgress.Name = "radInProgress";
            this.radInProgress.Size = new System.Drawing.Size(198, 44);
            this.radInProgress.TabIndex = 5;
            this.radInProgress.Text = "In Progress";
            this.radInProgress.UseVisualStyleBackColor = true;
            // 
            // radCompleted
            // 
            this.radCompleted.AutoSize = true;
            this.radCompleted.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radCompleted.Location = new System.Drawing.Point(1187, 384);
            this.radCompleted.Name = "radCompleted";
            this.radCompleted.Size = new System.Drawing.Size(189, 44);
            this.radCompleted.TabIndex = 6;
            this.radCompleted.Text = "Completed";
            this.radCompleted.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("MV Boli", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1335, 544);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 63);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmViewOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1498, 651);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.radCompleted);
            this.Controls.Add(this.radInProgress);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lstOrders);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblViewOrders);
            this.Controls.Add(this.background);
            this.Name = "frmViewOrders";
            this.Text = "View Orders";
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox background;
        private System.Windows.Forms.Label lblViewOrders;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ListBox lstOrders;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.RadioButton radInProgress;
        private System.Windows.Forms.RadioButton radCompleted;
        private System.Windows.Forms.Button btnSave;
    }
}