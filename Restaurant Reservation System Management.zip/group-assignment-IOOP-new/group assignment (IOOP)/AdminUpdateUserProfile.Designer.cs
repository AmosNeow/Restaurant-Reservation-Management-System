﻿namespace group_assignment__IOOP_
{
    partial class AdminUpdateUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminUpdateUserProfile));
            this.UpdateUserProfileMenu = new System.Windows.Forms.Label();
            this.MessageLabel = new System.Windows.Forms.Label();
            this.BackBtn = new System.Windows.Forms.Button();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.EmailTxt = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordTxt = new System.Windows.Forms.TextBox();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PhoneTxt = new System.Windows.Forms.TextBox();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.AgeTxt = new System.Windows.Forms.TextBox();
            this.AgeLabel = new System.Windows.Forms.Label();
            this.RoleLabel = new System.Windows.Forms.Label();
            this.NameTxt = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.IDLabel = new System.Windows.Forms.Label();
            this.IDComboBox = new System.Windows.Forms.ComboBox();
            this.RoleComboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // UpdateUserProfileMenu
            // 
            this.UpdateUserProfileMenu.AutoSize = true;
            this.UpdateUserProfileMenu.BackColor = System.Drawing.SystemColors.Highlight;
            this.UpdateUserProfileMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.UpdateUserProfileMenu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateUserProfileMenu.Location = new System.Drawing.Point(-12, -2);
            this.UpdateUserProfileMenu.MinimumSize = new System.Drawing.Size(820, 50);
            this.UpdateUserProfileMenu.Name = "UpdateUserProfileMenu";
            this.UpdateUserProfileMenu.Size = new System.Drawing.Size(820, 50);
            this.UpdateUserProfileMenu.TabIndex = 3;
            this.UpdateUserProfileMenu.Text = "   Update User Profile";
            this.UpdateUserProfileMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UpdateUserProfileMenu.Click += new System.EventHandler(this.UpdateUserProfileMenu_Click);
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-12, 402);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 9;
            this.MessageLabel.Text = "      Luna : Please input the new user profile.";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MessageLabel.Click += new System.EventHandler(this.MessageLabel_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Location = new System.Drawing.Point(548, 342);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(158, 35);
            this.BackBtn.TabIndex = 19;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // SaveBtn
            // 
            this.SaveBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.SaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SaveBtn.Location = new System.Drawing.Point(359, 342);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(158, 35);
            this.SaveBtn.TabIndex = 20;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = false;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(24, 100);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 21;
            this.ImageLabel.Click += new System.EventHandler(this.ImageLabel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 454);
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // EmailTxt
            // 
            this.EmailTxt.Location = new System.Drawing.Point(568, 159);
            this.EmailTxt.Name = "EmailTxt";
            this.EmailTxt.Size = new System.Drawing.Size(182, 22);
            this.EmailTxt.TabIndex = 76;
            this.EmailTxt.TextChanged += new System.EventHandler(this.EmailTxt_TextChanged);
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Location = new System.Drawing.Point(565, 206);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(67, 16);
            this.PasswordLabel.TabIndex = 75;
            this.PasswordLabel.Text = "Password";
            this.PasswordLabel.Click += new System.EventHandler(this.PasswordLabel_Click);
            // 
            // PasswordTxt
            // 
            this.PasswordTxt.Location = new System.Drawing.Point(568, 227);
            this.PasswordTxt.Name = "PasswordTxt";
            this.PasswordTxt.Size = new System.Drawing.Size(182, 22);
            this.PasswordTxt.TabIndex = 74;
            this.PasswordTxt.TextChanged += new System.EventHandler(this.PasswordTxt_TextChanged);
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(567, 140);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(95, 16);
            this.EmailLabel.TabIndex = 73;
            this.EmailLabel.Text = "Email Address";
            this.EmailLabel.Click += new System.EventHandler(this.EmailLabel_Click);
            // 
            // PhoneTxt
            // 
            this.PhoneTxt.Location = new System.Drawing.Point(568, 97);
            this.PhoneTxt.Name = "PhoneTxt";
            this.PhoneTxt.Size = new System.Drawing.Size(182, 22);
            this.PhoneTxt.TabIndex = 72;
            this.PhoneTxt.TextChanged += new System.EventHandler(this.PhoneTxt_TextChanged);
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.Location = new System.Drawing.Point(565, 78);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(97, 16);
            this.PhoneLabel.TabIndex = 71;
            this.PhoneLabel.Text = "Phone Number";
            this.PhoneLabel.Click += new System.EventHandler(this.PhoneLabel_Click);
            // 
            // AgeTxt
            // 
            this.AgeTxt.Location = new System.Drawing.Point(324, 296);
            this.AgeTxt.Name = "AgeTxt";
            this.AgeTxt.Size = new System.Drawing.Size(177, 22);
            this.AgeTxt.TabIndex = 70;
            this.AgeTxt.TextChanged += new System.EventHandler(this.AgeTxt_TextChanged);
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Location = new System.Drawing.Point(321, 277);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(32, 16);
            this.AgeLabel.TabIndex = 69;
            this.AgeLabel.Text = "Age";
            this.AgeLabel.Click += new System.EventHandler(this.AgeLabel_Click);
            // 
            // RoleLabel
            // 
            this.RoleLabel.AutoSize = true;
            this.RoleLabel.Location = new System.Drawing.Point(321, 206);
            this.RoleLabel.Name = "RoleLabel";
            this.RoleLabel.Size = new System.Drawing.Size(36, 16);
            this.RoleLabel.TabIndex = 67;
            this.RoleLabel.Text = "Role";
            this.RoleLabel.Click += new System.EventHandler(this.RoleLabel_Click);
            // 
            // NameTxt
            // 
            this.NameTxt.Location = new System.Drawing.Point(324, 159);
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.Size = new System.Drawing.Size(177, 22);
            this.NameTxt.TabIndex = 66;
            this.NameTxt.TextChanged += new System.EventHandler(this.NameTxt_TextChanged);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(321, 140);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(76, 16);
            this.NameLabel.TabIndex = 65;
            this.NameLabel.Text = "User Name";
            this.NameLabel.Click += new System.EventHandler(this.NameLabel_Click);
            // 
            // IDLabel
            // 
            this.IDLabel.AutoSize = true;
            this.IDLabel.Location = new System.Drawing.Point(321, 78);
            this.IDLabel.Name = "IDLabel";
            this.IDLabel.Size = new System.Drawing.Size(52, 16);
            this.IDLabel.TabIndex = 63;
            this.IDLabel.Text = "User ID";
            this.IDLabel.Click += new System.EventHandler(this.IDLabel_Click);
            // 
            // IDComboBox
            // 
            this.IDComboBox.FormattingEnabled = true;
            this.IDComboBox.Location = new System.Drawing.Point(324, 100);
            this.IDComboBox.Name = "IDComboBox";
            this.IDComboBox.Size = new System.Drawing.Size(177, 24);
            this.IDComboBox.TabIndex = 77;
            this.IDComboBox.SelectedIndexChanged += new System.EventHandler(this.IDcomboBox_SelectedIndexChanged);
            // 
            // RoleComboBox
            // 
            this.RoleComboBox.FormattingEnabled = true;
            this.RoleComboBox.Items.AddRange(new object[] {
            "Customer",
            "Admin",
            "Manager",
            "Chef",
            "Reservation Coordinator"});
            this.RoleComboBox.Location = new System.Drawing.Point(324, 225);
            this.RoleComboBox.Name = "RoleComboBox";
            this.RoleComboBox.Size = new System.Drawing.Size(177, 24);
            this.RoleComboBox.TabIndex = 78;
            this.RoleComboBox.SelectedIndexChanged += new System.EventHandler(this.RoleComboBox_SelectedIndexChanged);
            // 
            // AdminUpdateUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.RoleComboBox);
            this.Controls.Add(this.IDComboBox);
            this.Controls.Add(this.EmailTxt);
            this.Controls.Add(this.PasswordLabel);
            this.Controls.Add(this.PasswordTxt);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.PhoneTxt);
            this.Controls.Add(this.PhoneLabel);
            this.Controls.Add(this.AgeTxt);
            this.Controls.Add(this.AgeLabel);
            this.Controls.Add(this.RoleLabel);
            this.Controls.Add(this.NameTxt);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.IDLabel);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.UpdateUserProfileMenu);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminUpdateUserProfile";
            this.Text = "AdminUpdateUserProfile";
            this.Load += new System.EventHandler(this.AdminUpdateUserProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UpdateUserProfileMenu;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox EmailTxt;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox PasswordTxt;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox PhoneTxt;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.TextBox AgeTxt;
        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.Label RoleLabel;
        private System.Windows.Forms.TextBox NameTxt;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label IDLabel;
        private System.Windows.Forms.ComboBox IDComboBox;
        private System.Windows.Forms.ComboBox RoleComboBox;
    }
}