﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace group_assignment__IOOP_
{
    internal class Order
    {

        // Private Properties
        private int UserId { get; set; }
        private int FoodId { get; set; }
        private string Name { get; set; }
        private string Category { get; set; }
        private double Price { get; set; }
        private int Quantity { get; set; }

        // Constructor
        public Order(int userId, int foodId, string name, string category, double price, int quantity)
        {
            UserId = userId;
            FoodId = foodId;
            Name = name;
            Category = category;
            Price = price;
            Quantity = quantity;
        }

        // Method to Save Order in the Database
        public void SaveOrder()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO [Order] (User_Id, Food_Id, Name, Category, Price, Quantity) VALUES (@UserId, @FoodId, @Name, @Category, @Price, @Quantity)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.Parameters.AddWithValue("@FoodId", FoodId);
                    cmd.Parameters.AddWithValue("@Name", Name);
                    cmd.Parameters.AddWithValue("@Category", Category);
                    cmd.Parameters.AddWithValue("@Price", Price);
                    cmd.Parameters.AddWithValue("@Quantity", Quantity);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Method to Update Total Amount Paid
        public void UpdateTotalAmount()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;
            double totalCost = Price * Quantity;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE Total_Amount_Paid SET Total_Amount_Paid = Total_Amount_Paid + @TotalCost WHERE User_Id = @UserId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TotalCost", totalCost);
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Method to Return Order Details (for ListBox)
        public string GetOrderDetails()
        {
            return $"{Name} ({Category}) x{Quantity} - RM {Price * Quantity:0.00}";
        }

    }
}
