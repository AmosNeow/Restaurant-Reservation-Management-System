﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


internal class UserProfile
{
    public int userid { get; set; }
    public string username { get; set; }
    public string password { get; set; }
    public string email { get; set; }
    public string phone { get; set; }
    public int age { get; set; }
    public string role { get; set; }
    static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

    public UserProfile(int ui, string un, string pss, string em, string ph, int ag, string rl) //Update User Profile
    {
        userid = ui;
        username = un;
        password = pss;
        email = em;
        phone = ph;
        age = ag;
        role = rl;
    }

    public UserProfile(int ui,string un, string pss, string em, string ph, int ag) //Update Own Profile
    {
        userid = ui;
        username = un;
        password = pss;
        email = em;
        phone = ph;
        age = ag;
        role = null;
    }
    public UserProfile(string un, string pss, string em, string ph, int ag,string rl) //Add User Profile
    {
        userid = 0;
        username = un;
        password = pss;
        email = em;
        phone = ph;
        age = ag;
        role = rl;
    }
    public UserProfile(int ui) //Delete User Profile
    {
        userid = ui;
        username = null;
        password = null;
        email = null;
        phone = null;
        age = 0;
        role = null;
    }

    public static ArrayList ViewUPData()
    {
        ArrayList profile = new ArrayList();
        con.Open();
        SqlCommand cmd = new SqlCommand("SELECT * FROM Users", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            string result = $"{rd["User_ID"]}\t{rd["Name"]}\t{rd["Role"]}\t{rd["Age"]}\t{rd["Phone_number"]}\t{rd["Email"]}\t{rd["Password"]}";
            profile.Add(result);
        }
        con.Close();
        return profile;
    }

    public void AddUP()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("INSERT INTO Users (Name, Role, Age, Phone_number, Email, Password) VALUES (@Name, @Role, @Age, @Phone_number, @Email, @Password)", con);
        cmd.Parameters.AddWithValue("@Name", username);
        cmd.Parameters.AddWithValue("@Role", role);
        cmd.Parameters.AddWithValue("@Age", age);
        cmd.Parameters.AddWithValue("@Phone_number", phone);
        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@Password", password);
        cmd.ExecuteNonQuery();

        cmd.Parameters.Clear();

        MessageBox.Show("Data Added Successfully");
        con.Close();
    }

    public void UpdateUP()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("UPDATE Users SET Name = @Name,Role =@Role, Age = @Age, Phone_number = @Phone_number, Email = @Email, Password = @Password WHERE User_Id = @User_ID", con);
        cmd.Parameters.AddWithValue("@User_ID", userid);
        cmd.Parameters.AddWithValue("@Name", username);
        cmd.Parameters.AddWithValue("@Role", role);
        cmd.Parameters.AddWithValue("@Age", age);
        cmd.Parameters.AddWithValue("@Phone_number", phone);
        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@Password", password);
        cmd.ExecuteNonQuery();

        cmd.Parameters.Clear();

        MessageBox.Show("Data Updated Successfully");
        con.Close();
    }

    public void DeleteUP()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE User_Id = @User_ID", con);
        cmd.Parameters.AddWithValue("@User_ID", userid);
        cmd.ExecuteNonQuery();

        cmd.Parameters.Clear();

        MessageBox.Show("Data Deleted Successfully");
        con.Close();
    }

    public void UpdateOP()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("UPDATE Users SET Name = @Name, Age = @Age, Phone_number = @Phone_number, Email = @Email, Password = @Password WHERE User_Id = @User_ID", con);
        cmd.Parameters.AddWithValue("@User_ID", userid);
        cmd.Parameters.AddWithValue("@Name", username);
        cmd.Parameters.AddWithValue("@Age", age);
        cmd.Parameters.AddWithValue("@Phone_number", phone);
        cmd.Parameters.AddWithValue("@Email", email);
        cmd.Parameters.AddWithValue("@Password", password);
        cmd.ExecuteNonQuery();

        cmd.Parameters.Clear();

        MessageBox.Show("Profile Updated Successfully");
        con.Close();
    }
}


