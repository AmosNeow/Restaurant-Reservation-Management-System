﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Collections.Generic;

namespace IOOP_assignment
{
    class Chef_Class
    {
        
        //connection string to Chef Table
        public static readonly string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;
        //Change Form Button
        public static void Change_Form(Form Current_Form, Form New_Form)
        {
            // Hide the current form
            Current_Form.Hide();

            // Show the new form
            New_Form.Show();
        }






        // Get all ingredients from the Ingredient Table
        public List<Tuple<int, string, int>> GetIngredients()
        {
            List<Tuple<int, string, int>> ingredients = new List<Tuple<int, string, int>>();

            string query = "SELECT Ingredient_Id, Name, Quantity FROM Ingredient"; // Updated query to include Quantity
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    // Add a tuple with Ingredient_Id, Name, and Quantity
                    ingredients.Add(new Tuple<int, string, int>(
                        (int)reader["Ingredient_Id"],
                        (string)reader["Name"],
                        (int)reader["Quantity"]));  // Casting to the correct types
                }
            }

            return ingredients;
        }

        //Delete Ingredient
        public bool DeleteIngredient(int ingredientId)
        {
            string query = "DELETE FROM Ingredient WHERE Ingredient_Id = @IngredientId";

            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IngredientId", ingredientId);
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();
                return rowsAffected > 0;  // Return true if the deletion was successful
            }
        }

        //Add New Ingredient
        public static bool AddIngredient(string ingredientName, int quantity)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Ingredient (Name, Quantity) VALUES (@Name, @Quantity)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", ingredientName);
                cmd.Parameters.AddWithValue("@Quantity", quantity);

                try
                {
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0; // Returns true if insert was successful
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding ingredient: " + ex.Message);
                    return false;
                }
            }
        }






        public string GetOrderStatus(int orderId)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;
            string query = "SELECT Status FROM Order_Status WHERE User_Id = (SELECT User_Id FROM [Order] WHERE Order_Id = @OrderId)";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@OrderId", orderId);
                    conn.Open();
                    return cmd.ExecuteScalar()?.ToString(); // Fetch and return the status
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching order status: {ex.Message}");
                return null;
            }
        }


        // Method to update the order status in the database
        public void UpdateOrderStatus(int orderId, string status)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;
            string query = "UPDATE Order_Status SET Status = @Status WHERE User_Id = (SELECT User_Id FROM [Order] WHERE Order_Id = @OrderId)";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@OrderId", orderId);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating order status: {ex.Message}");
            }
        }














































    }
}    
