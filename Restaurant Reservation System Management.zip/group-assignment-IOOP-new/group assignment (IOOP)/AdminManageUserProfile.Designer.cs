﻿namespace group_assignment__IOOP_
{
    partial class AdminManageUserProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminManageUserProfile));
            this.ManageUserProfileMenu = new System.Windows.Forms.Label();
            this.MessageLabel = new System.Windows.Forms.Label();
            this.ViewUserProfileBtn = new System.Windows.Forms.Button();
            this.UpdateUserProfileBtn = new System.Windows.Forms.Button();
            this.DeleteUserProfileBtn = new System.Windows.Forms.Button();
            this.BackBtn = new System.Windows.Forms.Button();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AddUserProfileBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ManageUserProfileMenu
            // 
            this.ManageUserProfileMenu.AutoSize = true;
            this.ManageUserProfileMenu.BackColor = System.Drawing.SystemColors.Highlight;
            this.ManageUserProfileMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ManageUserProfileMenu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageUserProfileMenu.Location = new System.Drawing.Point(-12, -2);
            this.ManageUserProfileMenu.MinimumSize = new System.Drawing.Size(820, 50);
            this.ManageUserProfileMenu.Name = "ManageUserProfileMenu";
            this.ManageUserProfileMenu.Size = new System.Drawing.Size(820, 50);
            this.ManageUserProfileMenu.TabIndex = 1;
            this.ManageUserProfileMenu.Text = "   Manage User Profile";
            this.ManageUserProfileMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-12, 402);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 7;
            this.MessageLabel.Text = "      Luna : I see you click the button of manage user profile. Do you want to vi" +
    "ew, add, update, or delete user profile ?";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MessageLabel.Click += new System.EventHandler(this.MessageLabel_Click);
            // 
            // ViewUserProfileBtn
            // 
            this.ViewUserProfileBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ViewUserProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ViewUserProfileBtn.Location = new System.Drawing.Point(502, 64);
            this.ViewUserProfileBtn.Name = "ViewUserProfileBtn";
            this.ViewUserProfileBtn.Size = new System.Drawing.Size(198, 35);
            this.ViewUserProfileBtn.TabIndex = 8;
            this.ViewUserProfileBtn.Text = "View User Profile";
            this.ViewUserProfileBtn.UseVisualStyleBackColor = false;
            this.ViewUserProfileBtn.Click += new System.EventHandler(this.ViewUserProfileBtn_Click);
            // 
            // UpdateUserProfileBtn
            // 
            this.UpdateUserProfileBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UpdateUserProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UpdateUserProfileBtn.Location = new System.Drawing.Point(502, 204);
            this.UpdateUserProfileBtn.Name = "UpdateUserProfileBtn";
            this.UpdateUserProfileBtn.Size = new System.Drawing.Size(198, 35);
            this.UpdateUserProfileBtn.TabIndex = 9;
            this.UpdateUserProfileBtn.Text = "Update User Profile";
            this.UpdateUserProfileBtn.UseVisualStyleBackColor = false;
            this.UpdateUserProfileBtn.Click += new System.EventHandler(this.UpdateUserProfileBtn_Click);
            // 
            // DeleteUserProfileBtn
            // 
            this.DeleteUserProfileBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.DeleteUserProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DeleteUserProfileBtn.Location = new System.Drawing.Point(502, 277);
            this.DeleteUserProfileBtn.Name = "DeleteUserProfileBtn";
            this.DeleteUserProfileBtn.Size = new System.Drawing.Size(198, 35);
            this.DeleteUserProfileBtn.TabIndex = 10;
            this.DeleteUserProfileBtn.Text = "Delete User Profile";
            this.DeleteUserProfileBtn.UseVisualStyleBackColor = false;
            this.DeleteUserProfileBtn.Click += new System.EventHandler(this.DeleteUserProfileBtn_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Location = new System.Drawing.Point(502, 350);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(198, 35);
            this.BackBtn.TabIndex = 11;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(96, 93);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 454);
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // AddUserProfileBtn
            // 
            this.AddUserProfileBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.AddUserProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddUserProfileBtn.Location = new System.Drawing.Point(502, 133);
            this.AddUserProfileBtn.Name = "AddUserProfileBtn";
            this.AddUserProfileBtn.Size = new System.Drawing.Size(198, 35);
            this.AddUserProfileBtn.TabIndex = 43;
            this.AddUserProfileBtn.Text = "Add User Profile";
            this.AddUserProfileBtn.UseVisualStyleBackColor = false;
            this.AddUserProfileBtn.Click += new System.EventHandler(this.AddUserProfileBtn_Click);
            // 
            // AdminManageUserProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AddUserProfileBtn);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.DeleteUserProfileBtn);
            this.Controls.Add(this.UpdateUserProfileBtn);
            this.Controls.Add(this.ViewUserProfileBtn);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.ManageUserProfileMenu);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminManageUserProfile";
            this.Text = "AdminManageUserProfile";
            this.Load += new System.EventHandler(this.AdminManageUserProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ManageUserProfileMenu;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Button ViewUserProfileBtn;
        private System.Windows.Forms.Button UpdateUserProfileBtn;
        private System.Windows.Forms.Button DeleteUserProfileBtn;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button AddUserProfileBtn;
    }
}