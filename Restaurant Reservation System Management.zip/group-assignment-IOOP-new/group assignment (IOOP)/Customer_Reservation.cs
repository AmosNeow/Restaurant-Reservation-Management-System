﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_Reservation : Form
    {
        public Customer_Reservation()
        {
            InitializeComponent();
            dateDateTime.Value = DateTime.Now;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (numPeople.Value != 0 & dateDateTime.Value != null & comboTheme.SelectedIndex != -1)
            {
                int userId = User.LoggedInUser.UserId;
                int numberOfPeople = Convert.ToInt32(numPeople.Value);
                string dateTime = dateDateTime.Value.ToString("yyyy-MM-dd");
                string time = combTime.Text.ToString();
                string theme = comboTheme.SelectedItem.ToString();
                string hall = "";
                string status = "Processing";

                CusReservation reservation = new CusReservation(userId, numberOfPeople, dateTime, time, theme, hall, status);
                reservation.CusMakeReservation();

                MessageBox.Show("Your Reservation Request Sent Successfully!");

                numPeople.Value = 0;
                dateDateTime.Value = DateTime.Now;
                comboTheme.Text = "";
            }
            else
            {
                MessageBox.Show("Error: Incomplete Information.");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
