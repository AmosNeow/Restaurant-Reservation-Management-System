﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_ReservationStatus : Form
    {
        public Customer_ReservationStatus()
        {
            InitializeComponent();
        }

        

        private void btnBack_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }

        private void btnViewStatus_Click(object sender, EventArgs e)
        {
            int userId = User.LoggedInUser.UserId;
            txtReserDetails.Text = CusReservation.ViewReserDetails(userId);

            txtReserStatus.Text = CusReservation.ViewReserStatus(userId);
        }
    }
}
