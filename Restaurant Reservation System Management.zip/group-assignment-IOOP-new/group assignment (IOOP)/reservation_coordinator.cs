﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    
    public partial class reservation_coordinator : Form
    {
        
        public reservation_coordinator()
        {
            InitializeComponent();
        }



        private void button3_Click(object sender, EventArgs e)
        {
            ReservationClass.button = 4;
            Hall_Reservation_Detail t = new Hall_Reservation_Detail();
            t.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReservationClass.button = 1;
            if (listBoxReservations.SelectedIndex != -1)
            {
                ReservationClass.reservation_ID = Convert.ToInt32(listBoxReservations.SelectedValue);

                reservation_process t = new reservation_process();
                t.Show();
                this.Hide();


            }
            else
            {
                MessageBox.Show("Please select a reservation.");
            }


            
            
        }

        private void reservation_coordinator_Load(object sender, EventArgs e)
        {
            ReservationClass.pagew = 1;
            LoadPendingReservations();

            string query1 = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed'";
            ConfirmedReservations(query1);
            dateTimePicker1.Enabled = false;
        }
        private void LoadPendingReservations()
        {
            ReservationClass reservation = new ReservationClass();
            DataTable table = reservation.GetPendingReservations(); 

            listBoxReservations.DisplayMember = "Reservation_Id";  
            listBoxReservations.ValueMember = "Reservation_Id";    
            listBoxReservations.DataSource = table;               
        }



        private void ConfirmedReservations(string query)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    if (query.Contains("@date"))
                    {
                        string selectedDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                        cmd.Parameters.AddWithValue("@date", selectedDate);
                    }
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    listBoxComfirmed.DisplayMember = "Reservation_Id";  
                    listBoxComfirmed.ValueMember = "Reservation_Id";   
                    listBoxComfirmed.DataSource = table;         
                }

            }

        }


        private void btnReject_Click(object sender, EventArgs e)
        {
            

            
            if (listBoxReservations.SelectedIndex != -1)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this reservation?",
                                              "Confirmation",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    ReservationClass.reservation_ID = Convert.ToInt32(listBoxReservations.SelectedValue);
                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                    {
                        conn.Open();
                        string query = "DELETE FROM Reservation_Details WHERE Reservation_Id = @a";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@a", ReservationClass.reservation_ID);
                        cmd.ExecuteNonQuery(); 

                    }
                    LoadPendingReservations();
                }
            }
            else
            {
                MessageBox.Show("Please Select a Reservation ID");
                return;
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ReservationClass.button = 2;
            if (listBoxComfirmed.SelectedIndex != -1)
            {
                ReservationClass.reservation_ID = Convert.ToInt32(listBoxComfirmed.SelectedValue);

                reservation_process t = new reservation_process();
                t.Show();
                this.Hide();


            }
            else
            {
                MessageBox.Show("Please select a reservation.");
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Enabled = !(chkAllDate.Checked);
            if (chkAllDate.Checked == false)
            {
                string query = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed' AND date = @date";
                ConfirmedReservations(query); ;
            }
            else
            {
                string query1 = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed'";
                ConfirmedReservations(query1);
            }

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (chkAllDate.Checked == false)
            {
                string query = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed' AND date = @date";
                ConfirmedReservations(query); ;
            }
            else
            {
                string query1 = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed'";
                ConfirmedReservations(query1);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            if (listBoxReservations.SelectedIndex != -1)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this reservation?",
                                              "Confirmation",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    ReservationClass.reservation_ID = Convert.ToInt32(listBoxComfirmed.SelectedValue);
                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                    {
                        conn.Open();
                        string query = "DELETE FROM Reservation_Details WHERE Reservation_Id = @a";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@a", ReservationClass.reservation_ID);
                        cmd.ExecuteNonQuery();

                    }
                    if (chkAllDate.Checked == false)
                    {
                        string query2 = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed' AND date = @date";
                        ConfirmedReservations(query2); ;
                    }
                    else
                    {
                        string query1 = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'confirmed'";
                        ConfirmedReservations(query1);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please Select a Reservation ID");
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReservationClass.button = 3;
            reservation_process n = new reservation_process();
            n.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Reservation_UpdateProfile r = new Reservation_UpdateProfile();
            r.Show();
            this.Hide();
        }

        private void LogOutBtn_Click(object sender, EventArgs e)
        {
            LogIn l = new LogIn();
            l.Show();
            this.Hide();
        }
    }
}

