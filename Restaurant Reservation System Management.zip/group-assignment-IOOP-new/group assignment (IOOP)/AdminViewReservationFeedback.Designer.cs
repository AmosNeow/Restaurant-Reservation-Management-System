﻿namespace group_assignment__IOOP_
{
    partial class AdminViewReservationFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminViewReservationFeedback));
            this.listViewRF = new System.Windows.Forms.ListView();
            this.BackBtn = new System.Windows.Forms.Button();
            this.MessageLabel = new System.Windows.Forms.Label();
            this.ImageLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ViewReservationFeedbackMenu = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // listViewRF
            // 
            this.listViewRF.FullRowSelect = true;
            this.listViewRF.GridLines = true;
            this.listViewRF.HideSelection = false;
            this.listViewRF.Location = new System.Drawing.Point(362, 95);
            this.listViewRF.MultiSelect = false;
            this.listViewRF.Name = "listViewRF";
            this.listViewRF.Size = new System.Drawing.Size(398, 217);
            this.listViewRF.TabIndex = 47;
            this.listViewRF.UseCompatibleStateImageBehavior = false;
            this.listViewRF.View = System.Windows.Forms.View.Details;
            // 
            // BackBtn
            // 
            this.BackBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Location = new System.Drawing.Point(476, 334);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(198, 35);
            this.BackBtn.TabIndex = 45;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // MessageLabel
            // 
            this.MessageLabel.AutoSize = true;
            this.MessageLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.MessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MessageLabel.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageLabel.Location = new System.Drawing.Point(-10, 402);
            this.MessageLabel.MinimumSize = new System.Drawing.Size(820, 50);
            this.MessageLabel.Name = "MessageLabel";
            this.MessageLabel.Size = new System.Drawing.Size(820, 50);
            this.MessageLabel.TabIndex = 44;
            this.MessageLabel.Text = "      Luna : Here is all reservation feedbacks.";
            this.MessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ImageLabel
            // 
            this.ImageLabel.AutoSize = true;
            this.ImageLabel.Image = ((System.Drawing.Image)(resources.GetObject("ImageLabel.Image")));
            this.ImageLabel.Location = new System.Drawing.Point(52, 95);
            this.ImageLabel.MinimumSize = new System.Drawing.Size(250, 250);
            this.ImageLabel.Name = "ImageLabel";
            this.ImageLabel.Size = new System.Drawing.Size(250, 250);
            this.ImageLabel.TabIndex = 43;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 454);
            this.pictureBox1.TabIndex = 46;
            this.pictureBox1.TabStop = false;
            // 
            // ViewReservationFeedbackMenu
            // 
            this.ViewReservationFeedbackMenu.AutoSize = true;
            this.ViewReservationFeedbackMenu.BackColor = System.Drawing.SystemColors.Highlight;
            this.ViewReservationFeedbackMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ViewReservationFeedbackMenu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewReservationFeedbackMenu.Location = new System.Drawing.Point(-10, -2);
            this.ViewReservationFeedbackMenu.MinimumSize = new System.Drawing.Size(820, 50);
            this.ViewReservationFeedbackMenu.Name = "ViewReservationFeedbackMenu";
            this.ViewReservationFeedbackMenu.Size = new System.Drawing.Size(820, 50);
            this.ViewReservationFeedbackMenu.TabIndex = 48;
            this.ViewReservationFeedbackMenu.Text = "   View Reservation Feedback";
            this.ViewReservationFeedbackMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AdminViewReservationFeedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ViewReservationFeedbackMenu);
            this.Controls.Add(this.listViewRF);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.MessageLabel);
            this.Controls.Add(this.ImageLabel);
            this.Controls.Add(this.pictureBox1);
            this.Name = "AdminViewReservationFeedback";
            this.Text = "AdminViewReservationFeedback";
            this.Load += new System.EventHandler(this.AdminViewReservationFeedback_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewRF;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label MessageLabel;
        private System.Windows.Forms.Label ImageLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label ViewReservationFeedbackMenu;
    }
}