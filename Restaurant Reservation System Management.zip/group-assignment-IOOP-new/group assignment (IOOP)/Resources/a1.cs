﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_.Resources
{
    public partial class a1: Form
    {
        public a1()
        {
            InitializeComponent();
        }

        private void a1_Load(object sender, EventArgs e)
        {

        }
    }
}
