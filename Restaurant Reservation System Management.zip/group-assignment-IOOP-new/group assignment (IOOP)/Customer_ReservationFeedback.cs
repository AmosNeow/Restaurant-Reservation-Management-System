﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    
    public partial class Customer_ReservationFeedback : Form
    {
        private int loggedInUserId;
        int userId = User.LoggedInUser.UserId; 
        public Customer_ReservationFeedback()
        {
            InitializeComponent();
            loggedInUserId = userId;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string reserFeedback = txtFeedback.Text.Trim();

            if (reserFeedback == null)
            {
                MessageBox.Show("Please write your feedback.");
                return;
            }

            // Create Feedback object and send it to the database
            Feedback feedback = new Feedback(loggedInUserId, reserFeedback);
            feedback.SendReserFeedback();

            MessageBox.Show("Thank you for your feedback!");
            txtFeedback.Clear(); // Clear textbox after submission
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }
    }
}
