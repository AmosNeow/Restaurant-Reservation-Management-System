﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace group_assignment__IOOP_
{
    internal class DatabaseMenu
    {
        string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

        // Method to add a new menu item
        public bool AddMenuItem(MenuItem MenuItem)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Menu (Name, Category, Price) VALUES (@Name, @Category, @Price)";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Name", MenuItem.Name);
                    cmd.Parameters.AddWithValue("@Category", MenuItem.Category);
                    cmd.Parameters.AddWithValue("@Price", MenuItem.Price.ToString("F2"));

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Method to update an existing menu item
        public bool EditMenuItemPrice(string foodName, float newPrice)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Menu SET Price = @Price WHERE Name = @Name";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Name", foodName);
                    cmd.Parameters.AddWithValue("@Price", newPrice.ToString("F2"));

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0; // Check if update was successful
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating price: {ex.Message}");
                return false;
            }
        }


        // Method to delete a menu item by ID
        public bool DeleteMenuItem(int Food_id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Menu WHERE Food_id = @Food_id";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Food_id", Food_id);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0; // Returns true if row was deleted
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting item: {ex.Message}");
                return false;

            }
        }
    }
}
