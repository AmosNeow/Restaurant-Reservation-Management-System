﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace group_assignment__IOOP_
{
    internal class MenuItem
    {
        private int Food_id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public float Price { get; set; }

        public MenuItem(int menuItemID, string name, string categories, float price)
        {
            Food_id = menuItemID;
            Name = name;
            Category = categories;
            Price = price;
        }

        public MenuItem(string name, string categories, float price)
        {
            Name = name;
            Category = categories;
            Price = price;
        }
    }

}


