﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    internal class OrderItem
    {

        private int foodId;
        private string name;
        private string category;
        private decimal unitPrice;
        private int quantity;
   

        private static readonly string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

        public OrderItem(int foodId, string name, string category, decimal unitPrice, int quantity)
        {
            this.foodId = foodId;
            this.name = name;
            this.category = category;
            this.unitPrice = unitPrice;
            this.quantity = quantity;
        }

       
        public int GetFoodId() => foodId;
        public string GetName() => name;
        public string GetCategory() => category;
        public decimal GetUnitPrice() => unitPrice;
        public int GetQuantity() => quantity;

       
        public static void AddOrder(int foodId, string name, string category, decimal unitPrice, int quantity, ListBox listOrder, Label lblTotalAmount, List<OrderItem> orderList)
        {
            OrderItem newItem = new OrderItem(foodId, name, category, unitPrice, quantity);
            orderList.Add(newItem);
            listOrder.Items.Add($"{name} (x{quantity}) - RM {unitPrice * quantity}");

            UpdateTotalAmount(lblTotalAmount, orderList);
        }

        // Delete Selected Order Item
        public static void DeleteOrder(List<OrderItem> orderList, ListBox listOrder, Label lblTotalAmount)
        {
            if (listOrder.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an item in the order listbox to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int index = listOrder.SelectedIndex;
            orderList.RemoveAt(index);
            listOrder.Items.RemoveAt(index);

           
            UpdateTotalAmount(lblTotalAmount, orderList);
        }

        // Calculate and Update Total Amount
        public static void UpdateTotalAmount(Label lblTotalAmount, List<OrderItem> orderList)
        {
            decimal totalAmount = 0;
            foreach (OrderItem item in orderList)
            {
                totalAmount += item.GetUnitPrice() * item.GetQuantity();
            }
            lblTotalAmount.Text = $"RM {totalAmount:F2}";
        }

        // Save Order to Database
        public static void SaveOrderToDatabase(int userId, List<OrderItem> orderList)
        {
            if (orderList.Count == 0)
            {
                MessageBox.Show("No items to save.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ConnectionString))
            {
                con.Open();
                SqlTransaction transaction = con.BeginTransaction();

                try
                {
                    decimal totalAmount = 0;

                    foreach (OrderItem item in orderList)
                    {
                        string query = "INSERT INTO [Order] (Food_Id, User_Id, Name, Category, Price, Quantity) VALUES (@FoodId, @UserId, @Name, @Category, @Price, @Quantity)";
                        SqlCommand cmd = new SqlCommand(query, con, transaction);
                        cmd.Parameters.AddWithValue("@FoodId", item.GetFoodId());
                        cmd.Parameters.AddWithValue("@UserId", userId);
                        cmd.Parameters.AddWithValue("@Name", item.GetName());
                        cmd.Parameters.AddWithValue("@Category", item.GetCategory());
                        cmd.Parameters.AddWithValue("@Price", item.GetUnitPrice());
                        cmd.Parameters.AddWithValue("@Quantity", item.GetQuantity());
                        cmd.ExecuteNonQuery();

                        totalAmount += item.GetUnitPrice() * item.GetQuantity();
                    }

                    
                    string totalQuery = "INSERT INTO Total_Amount_Paid (User_Id, Total_Amount_Paid) VALUES (@UserId, @TotalAmount)";
                    SqlCommand totalCmd = new SqlCommand(totalQuery, con, transaction);
                    totalCmd.Parameters.AddWithValue("@UserId", userId);
                    totalCmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                    totalCmd.ExecuteNonQuery();

                    //Insert status to in progress
                    string statusQuery = "INSERT INTO Order_Status ( User_Id, Status) VALUES (@UserId, @Status)";
                    SqlCommand cmd1 = new SqlCommand(statusQuery, con, transaction);
                    cmd1.Parameters.AddWithValue("@UserId", userId);
                    cmd1.Parameters.AddWithValue("@Status", "In Progress");
                    cmd1.ExecuteNonQuery();


                    transaction.Commit();
                    MessageBox.Show("Order successfully saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    orderList.Clear();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show($"Error saving order: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        public static string ViewOrderDetails(int userId)
        {
            string details = "";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT Food_Id, Name, Category, Price, Quantity " +
                               "FROM [Order] WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            details +=
                         $"FoodID: {reader["Food_Id"]}{Environment.NewLine}" +
                         $"Name: {reader["Name"]}{Environment.NewLine}" +
                         $"Category: {reader["Category"]}{Environment.NewLine}" +
                         $"UnitPrice: {reader["Price"]}{Environment.NewLine}" +
                         $"Quantity: {reader["Quantity"]}{Environment.NewLine}" +
                         "------------------------------------------" + Environment.NewLine;
                        }
                    }
                }
            }
            if (string.IsNullOrEmpty(details))
            {
                return "No Orders found.";
            }
            else
            {
                return details;
            }
        }
        public static string ViewOrderStatus(int userId)
        {
            string status = "";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT Status " +
                               "FROM Order_Status WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            status += $"{reader["Status"]}\n";
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(status))
            {
                return "No Orders Found.";
            }
            else
            {
                return status;
            }
        }

        public static decimal GetUnitPriceByName(string itemName, List<OrderItem> orderList)
        {
            foreach (OrderItem item in orderList)
            {
                if (item.GetName().Equals(itemName, StringComparison.OrdinalIgnoreCase))
                {
                    return item.GetUnitPrice();
                }
            }
            return 0; // Default to 0 if item not found
        }

        public void UpdateQuantity(int newQuantity)
        {
            this.quantity = newQuantity;
        }
    }
}



