﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class Edit_Profile : Form
    {
        public Edit_Profile()
        {
            InitializeComponent();
        }

        Profile NP = new Profile();

        private void Loadtable()
        {
            LSBVP.Items.Clear();
            string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            // Step 2: Query the database
            string query = "SELECT * FROM Users WHERE Role = 'Manager'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Step 3: Execute the command
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    // Step 4: Load data into ListBox

                    while (reader.Read())
                    {
                        List<string> rowData = new List<string>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            rowData.Add(reader.GetValue(i).ToString().PadRight(9)); // Adjust width dynamically
                        }

                        LSBVP.Items.Add(string.Join(" ", rowData));
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadFields()
        {
            CBBEdit.Items.Add("Name");
            CBBEdit.Items.Add("Age");
            CBBEdit.Items.Add("Phone_number");
            CBBEdit.Items.Add("Password");
        }

        private void BttnExit_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Main_Page form2 = new Main_Page();

            // Show Form2
            form2.Show();

            // Hide the current form (Form1)
            this.Hide();
        }

        private void Edit_Profile_Load(object sender, EventArgs e)
        {
            LoadFields();
            Loadtable();
        }

        private void BTTNEP_Click(object sender, EventArgs e)
        {
            if (CBBEdit.SelectedItem == null || string.IsNullOrWhiteSpace(TXTBNI.Text))
            {
                MessageBox.Show("Please select a field and enter a value.");
                return;
            }

            string selectedField = CBBEdit.SelectedItem.ToString();

            if (NP.UpdateProfile(selectedField, TXTBNI.Text))
            {
                MessageBox.Show("Profile updated successfully!");
            }
            else
            {
                MessageBox.Show("Update failed. Check your input.");
            }
            Loadtable();

        }
    }
}
