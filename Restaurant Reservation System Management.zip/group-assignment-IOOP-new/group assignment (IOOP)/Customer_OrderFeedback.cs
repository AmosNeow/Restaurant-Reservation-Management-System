﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using MOK_IOOPassignment;

namespace group_assignment__IOOP_
{
    public partial class Customer_OrderFeedback : Form
    {
        private int loggedInUserId; // Store the logged-in user ID

        public Customer_OrderFeedback()
        {
            InitializeComponent();
            loggedInUserId = userId;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Customer_Main_Page obj1 = new Customer_Main_Page();
            obj1.Show();
            this.Hide();
        }

        int userId = User.LoggedInUser.UserId; //Get logged-in user ID
        private void btnSend_Click(object sender, EventArgs e)
        {
            string orderFeedback = txtFeedback.Text.Trim(); 

            if (orderFeedback == null)
            {
                MessageBox.Show("Please write your feedback.");
                return;
            }

            // Create Feedback object and send it to the database
            Feedback feedback = new Feedback(loggedInUserId, orderFeedback);
            feedback.SendOrderFeedback();

            MessageBox.Show("Thank you for your feedback!");
            txtFeedback.Clear(); // Clear textbox after submission
        }
    }
}
