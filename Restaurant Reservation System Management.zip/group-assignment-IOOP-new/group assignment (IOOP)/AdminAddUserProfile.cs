﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MOK_IOOPassignment;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class AdminAddUserProfile: Form
    {
        public AdminAddUserProfile()
        {
            InitializeComponent();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (
                string.IsNullOrWhiteSpace(NameTxt.Text) ||
                string.IsNullOrWhiteSpace(RoleComboBox.Text) ||
                string.IsNullOrWhiteSpace(AgeTxt.Text) ||
                string.IsNullOrWhiteSpace(PhoneTxt.Text) ||
                string.IsNullOrWhiteSpace(EmailTxt.Text) ||
                string.IsNullOrWhiteSpace(PasswordTxt.Text))
                {
                    MessageBox.Show("All fields must be filled out before saving.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // return to stop the function
                }
                else
                {
                    string username = NameTxt.Text;
                    string role = RoleComboBox.Text;
                    int age = Convert.ToInt32(AgeTxt.Text);
                    string phone = PhoneTxt.Text;
                    string email = EmailTxt.Text;
                    string password = PasswordTxt.Text;
                    UserProfile up = new UserProfile(username, password, email, phone, age, role);
                    up.AddUP();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Age must be integer. Please try again.");
            }
            
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminManageUserProfile manageuserprofile = new AdminManageUserProfile();
            manageuserprofile.Show();
            this.Close();
        }
    }
}
