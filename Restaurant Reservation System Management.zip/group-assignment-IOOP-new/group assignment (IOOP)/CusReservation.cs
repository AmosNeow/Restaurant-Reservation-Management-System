﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace group_assignment__IOOP_
{
    internal class CusReservation
    {
        private int UserId;
        private int NumberOfPeople;
        private string DateTime;
        private string Time;
        private string Theme;
        private string Status; 
        private string Hall; 
       

        private static readonly string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

        
        public CusReservation(int userId, int numberOfPeople, string dateTime, string time, string theme, string hall, string status)
        {
            UserId = userId;
            NumberOfPeople = numberOfPeople;
            DateTime = dateTime;
            Time = time;
            Theme = theme;
            Hall = hall;
            Status = status;
        }

        
        public void CusMakeReservation()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Reservation_Details (User_Id, Number_of_People, [Date], [time], Theme, Status, Hall) " +
                               "VALUES (@UserId, @NumberOfPeople, @Date, @Time, @Theme, @Status, @Hall)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.Parameters.AddWithValue("@NumberOfPeople", NumberOfPeople);
                    cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(DateTime));
                    cmd.Parameters.AddWithValue("@time", TimeSpan.Parse(Time));
                    cmd.Parameters.AddWithValue("@Theme", Theme);
                    cmd.Parameters.AddWithValue("@Status", Status);
                    cmd.Parameters.AddWithValue("@Hall", Hall);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        
        
        public static string ViewReserDetails(int userId)
        {
            string details = "";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT Reservation_Id, Number_of_People, [Date], [time], Theme, Status, Hall " +
                               "FROM Reservation_Details WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            details += $"ID: {reader["Reservation_Id"]}{Environment.NewLine}" +
                         $"People: {reader["Number_of_People"]}{Environment.NewLine}" +
                         $"Date: {Convert.ToDateTime(reader["Date"]).ToString("yyyy-MM-dd")}{Environment.NewLine}" +
                         $"Time: {reader["time"]}{Environment.NewLine}" +
                         $"Theme: {reader["Theme"]}{Environment.NewLine}" +
                         $"Status: {reader["Status"]}{Environment.NewLine}" +
                         $"Hall: {reader["Hall"]}{Environment.NewLine}" +
                         "-----------------------------------------" + Environment.NewLine;
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(details))
            {
                return "No reservations found.";
            }
            else
            {
                return details;
            }

        }

        public static string ViewReserStatus(int userId)
        {
            string status = "";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT Reservation_Id, Status " +
                               "FROM Reservation_Details WHERE User_Id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            status += $"ID: {reader["Reservation_Id"]}{Environment.NewLine}" +
                         $"Status: {reader["Status"]}{Environment.NewLine}" +
                         "------------------------------------" + Environment.NewLine;
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(status))
            {
                return "No reservations found.";
            }
            else
            {
                return status;
            }
        }
    }
}
