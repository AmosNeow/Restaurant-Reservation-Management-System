﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace group_assignment__IOOP_
{
    internal class Feedback
    {
        
        private int userId;
        private string userFeedback;

        
        public int UserId => userId;
        public string UserFeedback => userFeedback;

        
        private static readonly string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

        
        public Feedback(int userId, string userFeedback)
        {
            this.userId = userId;
            this.userFeedback = userFeedback;
        }

        public void SendOrderFeedback()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Order_Customer_Feedback (User_Id, Feedback) VALUES (@UserId, @Feedback)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@Feedback", userFeedback);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void SendReserFeedback()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Reservation_Feedback (User_Id, Feedback) VALUES (@UserId, @Feedback)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@Feedback", userFeedback);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }   

}
