﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public class ReservationClass
    {
        public static int pagew;
        public static int button;
        public static int reservation_ID;

        public DataTable GetPendingReservations()
        {
            DataTable table = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    conn.Open();
                    string query = "SELECT Reservation_Id FROM Reservation_Details WHERE Status = 'processing'";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(table);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading pending reservations: " + ex.Message);
            }
            return table;
        }

        public void LoadHall(ComboBox ComboBox, int page)
        {
            
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    conn.Open();
                    string query = "SELECT Hall_Id, Capacity FROM Hall_Details";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    if (page == 2)   //when the form is reservation_process
                    {
                        // Add a NULL option
                        DataRow newRow = table.NewRow();
                        newRow["Hall_Id"] = DBNull.Value;  // Set Hall_Id to empty
                        table.Rows.InsertAt(newRow, 0);  // Insert into the first row
                    }


                    ComboBox.DisplayMember = "Hall_Id";  // what the combobox displayed
                    ComboBox.ValueMember = "Hall_Id";    // The bound value (for querying)
                    ComboBox.DataSource = table;         // Binding Data

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Hall IDs: " + ex.Message);
            }
        }
        public DataTable LoadData(string query, string selectedDate, int hall)
        {
            DataTable table = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand(query, conn);

                    if (query.Contains("@date"))
                    {
                        cmd.Parameters.AddWithValue("@date", selectedDate);
                    }
                    if (query.Contains("@hall"))
                    {
                        cmd.Parameters.AddWithValue("@hall", Convert.ToInt32(hall));
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(table);


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return table;
        }

    }
}
