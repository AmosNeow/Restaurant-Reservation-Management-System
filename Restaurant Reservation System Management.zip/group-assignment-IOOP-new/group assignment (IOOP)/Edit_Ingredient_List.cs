﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOOP_assignment
{
    public partial class frmEditIngredientList : Form
    {
        public frmEditIngredientList()
        {
            InitializeComponent();
            LoadIngredients();
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmViewIngredients n = new frmViewIngredients();
            Chef_Class.Change_Form(this, n);
        }









        private void LoadIngredients()
        {
            Chef_Class chef = new Chef_Class();
            List<Tuple<int, string, int>> ingredients = chef.GetIngredients(); // Returns List<Tuple<int, string, int>>

            // Clear existing items
            lstIngredient.Items.Clear();
            cmbDeleteIngredient.Items.Clear();

            // Populate ListBox and ComboBox
            foreach (var ingredient in ingredients)
            {
                lstIngredient.Items.Add($"{ingredient.Item2} ({ingredient.Item3})"); // Add Name (Quantity) to ListBox
                cmbDeleteIngredient.Items.Add(ingredient); // Add Tuple to ComboBox
            }

            // Set DisplayMember and ValueMember for ComboBox
            cmbDeleteIngredient.DisplayMember = "Item2";  // Display ingredient name (Item2 in Tuple)
            cmbDeleteIngredient.ValueMember = "Item1";  // Store Ingredient_Id (Item1 in Tuple)
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            string ingredientName = txtNewIngredientName.Text.Trim();
            int quantity = (int)numNewIngredient.Value;

            if (!string.IsNullOrEmpty(ingredientName) && quantity > 0)
            {
                bool success = Chef_Class.AddIngredient(ingredientName, quantity);
                if (success)
                {
                    MessageBox.Show("Ingredient Added!");
                    LoadIngredients(); // Refresh ListBox
                }
                else
                {
                    MessageBox.Show("Failed to add ingredient.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid ingredient name and quantity.");
            }
        }


        


        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Debug: Check if an item is selected in the ComboBox
            if (cmbDeleteIngredient.SelectedItem != null)
            {
                var selectedIngredient = (Tuple<int, string, int>)cmbDeleteIngredient.SelectedItem;
                Console.WriteLine("Selected Ingredient: " + selectedIngredient.Item2); // Print the name

                int ingredientId = selectedIngredient.Item1; // Use Item1 (Ingredient_Id) for deletion

                Chef_Class chef = new Chef_Class();
                bool success = chef.DeleteIngredient(ingredientId);

                if (success)
                {
                    MessageBox.Show("Ingredient deleted successfully.");
                    LoadIngredients();  // Refresh ListBox & ComboBox
                }
                else
                {
                    MessageBox.Show("Failed to delete ingredient.");
                }
            }
            else
            {
                MessageBox.Show("Please select an ingredient to delete.");
            }
        }

        
    }
}
