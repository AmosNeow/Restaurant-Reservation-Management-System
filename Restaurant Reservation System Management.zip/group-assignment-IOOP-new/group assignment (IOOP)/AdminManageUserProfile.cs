﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class AdminManageUserProfile: Form
    {

        public AdminManageUserProfile()
        {
            InitializeComponent();
        }

        private void ViewUserProfileBtn_Click(object sender, EventArgs e)
        {
            AdminViewUserProfile viewuserprofile = new AdminViewUserProfile();
            viewuserprofile.Show();
            this.Hide();
        }

        private void UpdateUserProfileBtn_Click(object sender, EventArgs e)
        {
            AdminUpdateUserProfile updateuserprofile = new AdminUpdateUserProfile();
            updateuserprofile.Show();
            this.Hide();
        }

        private void DeleteUserProfileBtn_Click(object sender, EventArgs e)
        {
            AdminDeleteUserProfilecs deleteuserprofile = new AdminDeleteUserProfilecs();
            deleteuserprofile.Show();
            this.Hide();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminHomePage adminmenu = new AdminHomePage();
            adminmenu.Show();
            this.Close();
        }

        private void AdminManageUserProfile_Load(object sender, EventArgs e)
        {

        }

        private void MessageLabel_Click(object sender, EventArgs e)
        {
            
        }

        private void AddUserProfileBtn_Click(object sender, EventArgs e)
        {
            AdminAddUserProfile adduserprofile = new AdminAddUserProfile();
            adduserprofile.Show();
            this.Hide();
        }
    }
}
