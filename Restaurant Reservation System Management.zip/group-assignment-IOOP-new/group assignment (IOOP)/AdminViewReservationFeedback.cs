﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class AdminViewReservationFeedback: Form
    {
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminViewReservationFeedback()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminHomePage adminmenu = new AdminHomePage();
            adminmenu.Show();
            this.Close();
        }

        private void AdminViewReservationFeedback_Load(object sender, EventArgs e)
        {
            ListViewReservationFeedback();
        }

        public static ArrayList ViewRFData()
        {
            ArrayList feedback = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Reservation_Feedback", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string result = $"{rd["User_ID"]}\t{rd["Feedback"]}";
                feedback.Add(result);
            }
            con.Close();
            return feedback;
        }
        public void ListViewReservationFeedback()
        {
            listViewRF.Items.Clear();
            listViewRF.View = View.Details;
            listViewRF.Columns.Add("User ID", 100, HorizontalAlignment.Left);
            listViewRF.Columns.Add("Feedback", 100, HorizontalAlignment.Left);

            ArrayList profile1 = ViewRFData();
            foreach (var item in profile1)
            {
                string[] row = item.ToString().Split('\t');
                ListViewItem listViewItem = new ListViewItem(row[0]);
                for (int i = 1; i < row.Length; i++)
                {
                    listViewItem.SubItems.Add(row[i]);
                }
                listViewRF.Items.Add(listViewItem);
            }
        }
    }
}
