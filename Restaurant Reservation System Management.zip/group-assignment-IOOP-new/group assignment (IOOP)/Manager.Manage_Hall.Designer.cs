﻿using System;

namespace group_assignment__IOOP_
{
    partial class Manage_Hall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            this.Load += new EventHandler(Manage_Hall_Load);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manage_Hall));
            this.bttnEH = new System.Windows.Forms.Button();
            this.bttnDH = new System.Windows.Forms.Button();
            this.bttnAH = new System.Windows.Forms.Button();
            this.LSBHall = new System.Windows.Forms.ListBox();
            this.LBLMH = new System.Windows.Forms.Label();
            this.BttnExit = new System.Windows.Forms.Button();
            this.TXTBDH = new System.Windows.Forms.TextBox();
            this.LBLIHID = new System.Windows.Forms.Label();
            this.LBLOHID = new System.Windows.Forms.Label();
            this.TXTBHallID = new System.Windows.Forms.TextBox();
            this.TXTBNP = new System.Windows.Forms.TextBox();
            this.LBLNP = new System.Windows.Forms.Label();
            this.TXTBPrice = new System.Windows.Forms.TextBox();
            this.TXTBCapacity = new System.Windows.Forms.TextBox();
            this.LBLPrice = new System.Windows.Forms.Label();
            this.LBLCapacity = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.LBLNC = new System.Windows.Forms.Label();
            this.TXTBNC = new System.Windows.Forms.TextBox();
            this.lbl_Hallid = new System.Windows.Forms.Label();
            this.lbl_Capacity = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bttnEH
            // 
            this.bttnEH.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnEH.Location = new System.Drawing.Point(684, 470);
            this.bttnEH.Margin = new System.Windows.Forms.Padding(4);
            this.bttnEH.Name = "bttnEH";
            this.bttnEH.Size = new System.Drawing.Size(128, 43);
            this.bttnEH.TabIndex = 10;
            this.bttnEH.Text = "Edit Hall";
            this.bttnEH.UseVisualStyleBackColor = true;
            this.bttnEH.Click += new System.EventHandler(this.bttnEH_Click);
            // 
            // bttnDH
            // 
            this.bttnDH.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnDH.Location = new System.Drawing.Point(380, 470);
            this.bttnDH.Margin = new System.Windows.Forms.Padding(4);
            this.bttnDH.Name = "bttnDH";
            this.bttnDH.Size = new System.Drawing.Size(144, 43);
            this.bttnDH.TabIndex = 9;
            this.bttnDH.Text = "Delete Hall";
            this.bttnDH.UseVisualStyleBackColor = true;
            this.bttnDH.Click += new System.EventHandler(this.bttnDH_Click);
            // 
            // bttnAH
            // 
            this.bttnAH.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnAH.Location = new System.Drawing.Point(80, 470);
            this.bttnAH.Margin = new System.Windows.Forms.Padding(4);
            this.bttnAH.Name = "bttnAH";
            this.bttnAH.Size = new System.Drawing.Size(139, 43);
            this.bttnAH.TabIndex = 8;
            this.bttnAH.Text = "Add Hall";
            this.bttnAH.UseVisualStyleBackColor = true;
            this.bttnAH.Click += new System.EventHandler(this.bttnAH_Click);
            // 
            // LSBHall
            // 
            this.LSBHall.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LSBHall.FormattingEnabled = true;
            this.LSBHall.ItemHeight = 26;
            this.LSBHall.Location = new System.Drawing.Point(147, 98);
            this.LSBHall.Margin = new System.Windows.Forms.Padding(4);
            this.LSBHall.Name = "LSBHall";
            this.LSBHall.Size = new System.Drawing.Size(664, 134);
            this.LSBHall.TabIndex = 7;
            this.LSBHall.SelectedIndexChanged += new System.EventHandler(this.LSBHall_SelectedIndexChanged);
            // 
            // LBLMH
            // 
            this.LBLMH.AutoSize = true;
            this.LBLMH.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLMH.Location = new System.Drawing.Point(8, 11);
            this.LBLMH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLMH.Name = "LBLMH";
            this.LBLMH.Size = new System.Drawing.Size(178, 34);
            this.LBLMH.TabIndex = 6;
            this.LBLMH.Text = "Manage Hall";
            // 
            // BttnExit
            // 
            this.BttnExit.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnExit.Location = new System.Drawing.Point(949, 501);
            this.BttnExit.Margin = new System.Windows.Forms.Padding(4);
            this.BttnExit.Name = "BttnExit";
            this.BttnExit.Size = new System.Drawing.Size(101, 38);
            this.BttnExit.TabIndex = 12;
            this.BttnExit.Text = "Exit";
            this.BttnExit.UseVisualStyleBackColor = true;
            this.BttnExit.Click += new System.EventHandler(this.BttnExit_Click);
            // 
            // TXTBDH
            // 
            this.TXTBDH.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBDH.Location = new System.Drawing.Point(444, 330);
            this.TXTBDH.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBDH.Name = "TXTBDH";
            this.TXTBDH.Size = new System.Drawing.Size(132, 40);
            this.TXTBDH.TabIndex = 37;
            // 
            // LBLIHID
            // 
            this.LBLIHID.AutoSize = true;
            this.LBLIHID.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLIHID.Location = new System.Drawing.Point(331, 340);
            this.LBLIHID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLIHID.Name = "LBLIHID";
            this.LBLIHID.Size = new System.Drawing.Size(84, 26);
            this.LBLIHID.TabIndex = 36;
            this.LBLIHID.Text = "Hall ID:";
            // 
            // LBLOHID
            // 
            this.LBLOHID.AutoSize = true;
            this.LBLOHID.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLOHID.Location = new System.Drawing.Point(645, 334);
            this.LBLOHID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLOHID.Name = "LBLOHID";
            this.LBLOHID.Size = new System.Drawing.Size(84, 26);
            this.LBLOHID.TabIndex = 35;
            this.LBLOHID.Text = "Hall ID:";
            // 
            // TXTBHallID
            // 
            this.TXTBHallID.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBHallID.Location = new System.Drawing.Point(761, 322);
            this.TXTBHallID.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBHallID.Name = "TXTBHallID";
            this.TXTBHallID.Size = new System.Drawing.Size(132, 40);
            this.TXTBHallID.TabIndex = 34;
            // 
            // TXTBNP
            // 
            this.TXTBNP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBNP.Location = new System.Drawing.Point(761, 418);
            this.TXTBNP.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBNP.Name = "TXTBNP";
            this.TXTBNP.Size = new System.Drawing.Size(132, 40);
            this.TXTBNP.TabIndex = 33;
            // 
            // LBLNP
            // 
            this.LBLNP.AutoSize = true;
            this.LBLNP.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLNP.Location = new System.Drawing.Point(628, 422);
            this.LBLNP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLNP.Name = "LBLNP";
            this.LBLNP.Size = new System.Drawing.Size(116, 26);
            this.LBLNP.TabIndex = 32;
            this.LBLNP.Text = "New Price:";
            // 
            // TXTBPrice
            // 
            this.TXTBPrice.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBPrice.Location = new System.Drawing.Point(145, 373);
            this.TXTBPrice.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBPrice.Name = "TXTBPrice";
            this.TXTBPrice.Size = new System.Drawing.Size(132, 40);
            this.TXTBPrice.TabIndex = 31;
            // 
            // TXTBCapacity
            // 
            this.TXTBCapacity.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBCapacity.Location = new System.Drawing.Point(145, 325);
            this.TXTBCapacity.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBCapacity.Name = "TXTBCapacity";
            this.TXTBCapacity.Size = new System.Drawing.Size(132, 40);
            this.TXTBCapacity.TabIndex = 30;
            // 
            // LBLPrice
            // 
            this.LBLPrice.AutoSize = true;
            this.LBLPrice.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLPrice.Location = new System.Drawing.Point(51, 377);
            this.LBLPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLPrice.Name = "LBLPrice";
            this.LBLPrice.Size = new System.Drawing.Size(65, 26);
            this.LBLPrice.TabIndex = 29;
            this.LBLPrice.Text = "Price:";
            // 
            // LBLCapacity
            // 
            this.LBLCapacity.AutoSize = true;
            this.LBLCapacity.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLCapacity.Location = new System.Drawing.Point(28, 334);
            this.LBLCapacity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLCapacity.Name = "LBLCapacity";
            this.LBLCapacity.Size = new System.Drawing.Size(102, 26);
            this.LBLCapacity.TabIndex = 28;
            this.LBLCapacity.Text = "Capacity：";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // LBLNC
            // 
            this.LBLNC.AutoSize = true;
            this.LBLNC.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLNC.Location = new System.Drawing.Point(595, 374);
            this.LBLNC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLNC.Name = "LBLNC";
            this.LBLNC.Size = new System.Drawing.Size(149, 26);
            this.LBLNC.TabIndex = 38;
            this.LBLNC.Text = "New Capacity:";
            // 
            // TXTBNC
            // 
            this.TXTBNC.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTBNC.Location = new System.Drawing.Point(761, 370);
            this.TXTBNC.Margin = new System.Windows.Forms.Padding(4);
            this.TXTBNC.Name = "TXTBNC";
            this.TXTBNC.Size = new System.Drawing.Size(132, 40);
            this.TXTBNC.TabIndex = 39;
            this.TXTBNC.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbl_Hallid
            // 
            this.lbl_Hallid.AutoSize = true;
            this.lbl_Hallid.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hallid.Location = new System.Drawing.Point(142, 69);
            this.lbl_Hallid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Hallid.Name = "lbl_Hallid";
            this.lbl_Hallid.Size = new System.Drawing.Size(72, 26);
            this.lbl_Hallid.TabIndex = 40;
            this.lbl_Hallid.Text = "Hall_id";
            this.lbl_Hallid.Click += new System.EventHandler(this.lbl_Hallid_Click);
            // 
            // lbl_Capacity
            // 
            this.lbl_Capacity.AutoSize = true;
            this.lbl_Capacity.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Capacity.Location = new System.Drawing.Point(349, 68);
            this.lbl_Capacity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Capacity.Name = "lbl_Capacity";
            this.lbl_Capacity.Size = new System.Drawing.Size(91, 26);
            this.lbl_Capacity.TabIndex = 41;
            this.lbl_Capacity.Text = "Capacity";
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_price.Location = new System.Drawing.Point(617, 68);
            this.lbl_price.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(58, 26);
            this.lbl_price.TabIndex = 42;
            this.lbl_price.Text = "Price";
            this.lbl_price.Click += new System.EventHandler(this.lbl_price_Click);
            // 
            // Manage_Hall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lbl_price);
            this.Controls.Add(this.lbl_Capacity);
            this.Controls.Add(this.lbl_Hallid);
            this.Controls.Add(this.TXTBNC);
            this.Controls.Add(this.LBLNC);
            this.Controls.Add(this.TXTBDH);
            this.Controls.Add(this.LBLIHID);
            this.Controls.Add(this.LBLOHID);
            this.Controls.Add(this.TXTBHallID);
            this.Controls.Add(this.TXTBNP);
            this.Controls.Add(this.LBLNP);
            this.Controls.Add(this.TXTBPrice);
            this.Controls.Add(this.TXTBCapacity);
            this.Controls.Add(this.LBLPrice);
            this.Controls.Add(this.LBLCapacity);
            this.Controls.Add(this.BttnExit);
            this.Controls.Add(this.bttnEH);
            this.Controls.Add(this.bttnDH);
            this.Controls.Add(this.bttnAH);
            this.Controls.Add(this.LSBHall);
            this.Controls.Add(this.LBLMH);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Manage_Hall";
            this.Text = "Manage_Hall";
            this.Load += new System.EventHandler(this.Manage_Hall_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttnEH;
        private System.Windows.Forms.Button bttnDH;
        private System.Windows.Forms.Button bttnAH;
        private System.Windows.Forms.ListBox LSBHall;
        private System.Windows.Forms.Label LBLMH;
        private System.Windows.Forms.Button BttnExit;
        private System.Windows.Forms.TextBox TXTBDH;
        private System.Windows.Forms.Label LBLIHID;
        private System.Windows.Forms.Label LBLOHID;
        private System.Windows.Forms.TextBox TXTBHallID;
        private System.Windows.Forms.TextBox TXTBNP;
        private System.Windows.Forms.Label LBLNP;
        private System.Windows.Forms.TextBox TXTBPrice;
        private System.Windows.Forms.TextBox TXTBCapacity;
        private System.Windows.Forms.Label LBLPrice;
        private System.Windows.Forms.Label LBLCapacity;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label LBLNC;
        private System.Windows.Forms.TextBox TXTBNC;
        private System.Windows.Forms.Label lbl_Hallid;
        private System.Windows.Forms.Label lbl_Capacity;
        private System.Windows.Forms.Label lbl_price;
    }
}