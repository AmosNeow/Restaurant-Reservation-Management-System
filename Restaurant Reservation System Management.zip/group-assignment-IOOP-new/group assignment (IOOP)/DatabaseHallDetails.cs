﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    internal class DatabaseHallDetails
    {
        string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

        // Method to add a new menu item
        public bool AddHallDetails(HallDetails hallDetails)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Hall_Details (Capacity, Price) VALUES (@Capacity, @Price)";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Capacity", hallDetails.Capacity);
                    cmd.Parameters.AddWithValue("@Price", hallDetails.Price);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Method to update an existing menu item
        public bool UpdateHallCapacityPrice(int Hall_id,int newCapacity, int newPrice)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Hall_Details SET Capacity = @Capacity, Price = @Price WHERE Hall_id = @Hall_id";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Hall_id", Hall_id);
                    cmd.Parameters.AddWithValue("@Capacity", newCapacity);
                    cmd.Parameters.AddWithValue("@Price", newPrice);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0; // Check if update was successful
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating price: {ex.Message}");
                return false;
            }
        }


        // Method to delete a menu item by ID
        public bool DeleteHall(int Hall_id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Hall_Details WHERE Hall_id = @Hall_id";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Hall_id", Hall_id);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0; // Returns true if row was deleted
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting item: {ex.Message}");
                return false;

            }
        }
    }
}
