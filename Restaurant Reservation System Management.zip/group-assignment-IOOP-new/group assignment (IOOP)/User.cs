﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{


   
        internal class User
        {
            public int UserId { get; private set; }
            public string Name { get; set; }
            public string Role { get; set; }
            public string Email { get; set; }

          
            public static User LoggedInUser { get; private set; }

            private static readonly string connectionString = ConfigurationManager.ConnectionStrings["myCS"].ConnectionString;

            public User(int userId, string name, string role, string email)
            {
                UserId = userId;
                Name = name;
                Role = role;
                Email = email;
            }

            public static User Login(string email, string password)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = "SELECT User_Id, Name, Role, Email FROM Users WHERE Email = @Email AND Password = @Password";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", email.Trim());
                        cmd.Parameters.AddWithValue("@Password", password.Trim());

                        try
                        {
                            con.Open();
                            SqlDataReader reader = cmd.ExecuteReader();

                            if (reader.Read()) 
                            {
                                LoggedInUser = new User(
                                    Convert.ToInt32(reader["User_Id"]),
                                    reader["Name"].ToString(),
                                    reader["Role"].ToString(),
                                    reader["Email"].ToString()
                                );

                                return LoggedInUser;
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
                return null;
            }
        }
    }
    

