﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class reservation_process : Form
    {
        public reservation_process()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReservationClass.pagew = 2;
            Hall_Reservation_Detail t = new Hall_Reservation_Detail();
            t.Show();


        }

        //back button
        private void button3_Click(object sender, EventArgs e)
        {
            reservation_coordinator rc = new reservation_coordinator();
            rc.Show();
            this.Hide();

        }

        private void reservation_process_Load(object sender, EventArgs e)
        {

            ReservationClass load = new ReservationClass();
            load.LoadHall(cbHall1, 2);


            if (ReservationClass.button == 1)
            {
                loadreservation_process();
                txtPeople.Enabled = false;
                txtDate.Enabled = false;
                txtTime.Enabled = false;
                txtTheme.Enabled = false;
                txtUserID.Visible = false;
                btnAddNew.Visible = false;


            }
            else if (ReservationClass.button == 2)
            {
                loadreservation_process();
                txtPeople.Enabled = true;
                txtDate.Enabled = true;
                txtTime.Enabled = true;
                txtTheme.Enabled = true;
                txtUserID.Visible = false;
                btnAddNew.Visible = false;
                btnAccept.Text = "Save";
                btnReject.Text = "Delete";

            }
            else if (ReservationClass.button == 3)
            {
                lblName.Enabled = true;
                txtPeople.Enabled = true;
                txtDate.Enabled = true;
                txtTime.Enabled = true;
                txtTheme.Enabled = true;
                btnAccept.Visible = false;
                btnReject.Visible = false;
                lblUserId.Visible = false;


            }
        }



        private void loadreservation_process()
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
            {
                conn.Open();

                string query = @"
            SELECT rd.Reservation_Id, rd.User_Id, rd.Number_of_People, rd.Date, rd.Time, rd.Theme, u.Name ,rd.Hall
            FROM Reservation_Details rd 
            INNER JOIN Users u ON rd.User_Id = u.User_Id 
            WHERE rd.Reservation_Id = @a";


                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.Add("@a", SqlDbType.Int).Value = ReservationClass.reservation_ID;

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) // if find the data
                        {
                            lblReservationID.Text = reader["Reservation_Id"].ToString();
                            lblUserId.Text = reader["User_Id"].ToString();
                            txtPeople.Text = reader["Number_of_People"].ToString();
                            txtDate.Text = Convert.ToDateTime(reader["Date"]).ToString("yyyy-MM-dd");
                            txtTime.Text = reader["Time"].ToString();
                            txtTheme.Text = reader["Theme"].ToString();
                            lblName.Text = reader["Name"].ToString();


                            string hallValue = reader["Hall"]?.ToString().Trim();

                            if (int.TryParse(hallValue, out int hallId))
                            {
                                cbHall1.SelectedValue = hallId;
                            }
                            else
                            {
                                cbHall1.SelectedIndex = 0;
                            }

                        }
                        else
                        {
                            MessageBox.Show("No reservation found.");
                        }
                    }
                }
            }
        }

        


        private void button2_Click(object sender, EventArgs e)
        {
            updateTable();
           
        }


        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete this reservation?",
                                              "Confirmation",
                                              MessageBoxButtons.YesNo,
                                              MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                int reservation_ID = Convert.ToInt32(lblReservationID.Text);
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    conn.Open();
                    string query = "DELETE FROM Reservation_Details WHERE Reservation_Id = @a";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@a", reservation_ID);
                    cmd.ExecuteNonQuery(); // Performing a DELETE Operation

                }
                reservation_coordinator w = new reservation_coordinator();
                w.Show();
                this.Hide();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            updateTable();

        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {

        }

        private void updateTable()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
                {
                    conn.Open();
                    string query = "";

                    if (ReservationClass.button == 1)
                    {
                        query = @"UPDATE Reservation_Details 
                                     SET Number_of_People = @people, Date = @date, Time = @time, Theme = @theme, Hall = @hall ,Status = 'Confirmed'
                                     WHERE Reservation_Id = @reservationId";

                    }
                    else if (ReservationClass.button == 2)
                    {
                        query = @"UPDATE Reservation_Details 
                                     SET Number_of_People = @people, Date = @date, Time = @time, Theme = @theme, Hall = @hall
                                     WHERE Reservation_Id = @reservationId";

                    }
                    else if (ReservationClass.button == 3)
                    {
                        query = @"INSERT INTO Reservation_Details (User_Id, Number_of_People, Date, Time, Theme, Status, Hall)
                          VALUES (@userId, @people, @date, @time, @theme, 'confirmed', @hall);

                          SELECT SCOPE_IDENTITY();";

                    }




                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        if (!int.TryParse(txtPeople.Text, out int numberOfPeople))
                        {
                            MessageBox.Show("Invalid number of people!");
                            return;
                        }
                        cmd.Parameters.AddWithValue("@people", numberOfPeople);

                        if (!DateTime.TryParse(txtDate.Text, out DateTime dateValue))
                        {
                            MessageBox.Show("Invalid date format! Use YYYY-MM-DD.");
                            return;
                        }
                        cmd.Parameters.AddWithValue("@date", dateValue);

                        if (!TimeSpan.TryParse(txtTime.Text, out TimeSpan timeValue))
                        {
                            MessageBox.Show("Invalid time format! Use HH:mm:ss.");
                            return;
                        }
                        cmd.Parameters.AddWithValue("@time", timeValue);
                        cmd.Parameters.AddWithValue("@theme", txtTheme.Text);
                        cmd.Parameters.AddWithValue("@hall", Convert.ToInt32(cbHall1.SelectedValue));

                        if (ReservationClass.button == 1 || ReservationClass.button == 2)
                        {
                            cmd.Parameters.AddWithValue("@reservationId", int.Parse(lblReservationID.Text));
                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Reservation updated successfully.");
                            }
                            else
                            {
                                MessageBox.Show("No reservation was updated.");
                            }
                            reservation_coordinator w = new reservation_coordinator();
                            w.Show();
                            this.Hide();

                        }
                        else if (ReservationClass.button == 3)
                        {
                            // insert new reservation
                            cmd.Parameters.AddWithValue("@userId", int.Parse(txtUserID.Text));

                            
                            int newReservationId = Convert.ToInt32(cmd.ExecuteScalar());
                            MessageBox.Show($"Reservation added successfully!\n Reservation ID: {newReservationId}");
                            reservation_coordinator r = new reservation_coordinator();
                            r.Show();
                            this.Hide();
                        }

                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating reservation: " + ex.Message);
            }
        }
     



    }
}
