﻿namespace group_assignment__IOOP_
{
    partial class View_Hall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(View_Hall));
            this.LSBHRT = new System.Windows.Forms.ListBox();
            this.LBLHRT = new System.Windows.Forms.Label();
            this.BttnExit = new System.Windows.Forms.Button();
            this.LBLReservationid = new System.Windows.Forms.Label();
            this.LBLUserid = new System.Windows.Forms.Label();
            this.LBLCapacity = new System.Windows.Forms.Label();
            this.LBLTime = new System.Windows.Forms.Label();
            this.LBLTheme = new System.Windows.Forms.Label();
            this.LBLStatus = new System.Windows.Forms.Label();
            this.LBLHall = new System.Windows.Forms.Label();
            this.LBLDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LSBHRT
            // 
            this.LSBHRT.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LSBHRT.FormattingEnabled = true;
            this.LSBHRT.ItemHeight = 26;
            this.LSBHRT.Location = new System.Drawing.Point(86, 198);
            this.LSBHRT.Margin = new System.Windows.Forms.Padding(4);
            this.LSBHRT.Name = "LSBHRT";
            this.LSBHRT.Size = new System.Drawing.Size(1061, 186);
            this.LSBHRT.TabIndex = 4;
            // 
            // LBLHRT
            // 
            this.LBLHRT.AutoSize = true;
            this.LBLHRT.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLHRT.Location = new System.Drawing.Point(4, 11);
            this.LBLHRT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLHRT.Name = "LBLHRT";
            this.LBLHRT.Size = new System.Drawing.Size(339, 34);
            this.LBLHRT.TabIndex = 3;
            this.LBLHRT.Text = "Hall Reservation Record";
            this.LBLHRT.Click += new System.EventHandler(this.lblHRT_Click);
            // 
            // BttnExit
            // 
            this.BttnExit.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BttnExit.Location = new System.Drawing.Point(949, 503);
            this.BttnExit.Margin = new System.Windows.Forms.Padding(4);
            this.BttnExit.Name = "BttnExit";
            this.BttnExit.Size = new System.Drawing.Size(101, 36);
            this.BttnExit.TabIndex = 12;
            this.BttnExit.Text = "Exit";
            this.BttnExit.UseVisualStyleBackColor = true;
            this.BttnExit.Click += new System.EventHandler(this.BttnExit_Click);
            // 
            // LBLReservationid
            // 
            this.LBLReservationid.AutoSize = true;
            this.LBLReservationid.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLReservationid.Location = new System.Drawing.Point(13, 168);
            this.LBLReservationid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLReservationid.Name = "LBLReservationid";
            this.LBLReservationid.Size = new System.Drawing.Size(146, 26);
            this.LBLReservationid.TabIndex = 13;
            this.LBLReservationid.Text = "Reservation_id";
            this.LBLReservationid.Click += new System.EventHandler(this.lblReservationid_Click);
            // 
            // LBLUserid
            // 
            this.LBLUserid.AutoSize = true;
            this.LBLUserid.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLUserid.Location = new System.Drawing.Point(177, 168);
            this.LBLUserid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLUserid.Name = "LBLUserid";
            this.LBLUserid.Size = new System.Drawing.Size(78, 26);
            this.LBLUserid.TabIndex = 14;
            this.LBLUserid.Text = "User_id";
            // 
            // LBLCapacity
            // 
            this.LBLCapacity.AutoSize = true;
            this.LBLCapacity.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLCapacity.Location = new System.Drawing.Point(280, 168);
            this.LBLCapacity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLCapacity.Name = "LBLCapacity";
            this.LBLCapacity.Size = new System.Drawing.Size(91, 26);
            this.LBLCapacity.TabIndex = 15;
            this.LBLCapacity.Text = "Capacity";
            // 
            // LBLTime
            // 
            this.LBLTime.AutoSize = true;
            this.LBLTime.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLTime.Location = new System.Drawing.Point(631, 168);
            this.LBLTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLTime.Name = "LBLTime";
            this.LBLTime.Size = new System.Drawing.Size(57, 26);
            this.LBLTime.TabIndex = 16;
            this.LBLTime.Text = "Time";
            // 
            // LBLTheme
            // 
            this.LBLTheme.AutoSize = true;
            this.LBLTheme.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLTheme.Location = new System.Drawing.Point(824, 168);
            this.LBLTheme.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLTheme.Name = "LBLTheme";
            this.LBLTheme.Size = new System.Drawing.Size(73, 26);
            this.LBLTheme.TabIndex = 17;
            this.LBLTheme.Text = "Theme";
            this.LBLTheme.Click += new System.EventHandler(this.lblTheme_Click);
            // 
            // LBLStatus
            // 
            this.LBLStatus.AutoSize = true;
            this.LBLStatus.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLStatus.Location = new System.Drawing.Point(966, 168);
            this.LBLStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLStatus.Name = "LBLStatus";
            this.LBLStatus.Size = new System.Drawing.Size(75, 26);
            this.LBLStatus.TabIndex = 18;
            this.LBLStatus.Text = "Status";
            // 
            // LBLHall
            // 
            this.LBLHall.AutoSize = true;
            this.LBLHall.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLHall.Location = new System.Drawing.Point(1074, 168);
            this.LBLHall.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLHall.Name = "LBLHall";
            this.LBLHall.Size = new System.Drawing.Size(47, 26);
            this.LBLHall.TabIndex = 19;
            this.LBLHall.Text = "Hall";
            // 
            // LBLDate
            // 
            this.LBLDate.AutoSize = true;
            this.LBLDate.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLDate.Location = new System.Drawing.Point(447, 168);
            this.LBLDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBLDate.Name = "LBLDate";
            this.LBLDate.Size = new System.Drawing.Size(57, 26);
            this.LBLDate.TabIndex = 20;
            this.LBLDate.Text = "Date";
            this.LBLDate.Click += new System.EventHandler(this.label1_Click);
            // 
            // View_Hall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1212, 554);
            this.Controls.Add(this.LBLDate);
            this.Controls.Add(this.LBLHall);
            this.Controls.Add(this.LBLStatus);
            this.Controls.Add(this.LBLTheme);
            this.Controls.Add(this.LBLTime);
            this.Controls.Add(this.LBLCapacity);
            this.Controls.Add(this.LBLUserid);
            this.Controls.Add(this.LBLReservationid);
            this.Controls.Add(this.BttnExit);
            this.Controls.Add(this.LSBHRT);
            this.Controls.Add(this.LBLHRT);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "View_Hall";
            this.Text = "View Hall Reservation";
            this.Load += new System.EventHandler(this.View_Hall_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LSBHRT;
        private System.Windows.Forms.Label LBLHRT;
        private System.Windows.Forms.Button BttnExit;
        private System.Windows.Forms.Label LBLReservationid;
        private System.Windows.Forms.Label LBLUserid;
        private System.Windows.Forms.Label LBLCapacity;
        private System.Windows.Forms.Label LBLTime;
        private System.Windows.Forms.Label LBLTheme;
        private System.Windows.Forms.Label LBLStatus;
        private System.Windows.Forms.Label LBLHall;
        private System.Windows.Forms.Label LBLDate;
    }
}