﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace group_assignment__IOOP_
{
    public partial class AdminViewUserProfile: Form
    {
        public AdminViewUserProfile()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminManageUserProfile manageuserprofile = new AdminManageUserProfile();
            manageuserprofile.Show();
            this.Close();
        }

        private void MessageLabel_Click(object sender, EventArgs e)
        {

        }

        private void listViewUP_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void ListViewUP()
        {
            listViewUP.Items.Clear();
            listViewUP.View = View.Details;
            listViewUP.Columns.Add("User ID", 100, HorizontalAlignment.Left);
            listViewUP.Columns.Add("Name", 100, HorizontalAlignment.Left);
            listViewUP.Columns.Add("Role", 100, HorizontalAlignment.Left);
            listViewUP.Columns.Add("Age", 100, HorizontalAlignment.Left);
            listViewUP.Columns.Add("Phone", 100, HorizontalAlignment.Left);
            listViewUP.Columns.Add("Email", 200, HorizontalAlignment.Left);
            listViewUP.Columns.Add("Password", 100, HorizontalAlignment.Left);


            ArrayList profile1 = UserProfile.ViewUPData();
            foreach (var item in profile1)
            {
                string[] row = item.ToString().Split('\t');
                ListViewItem listViewItem = new ListViewItem(row[0]); 
                for (int i = 1; i < row.Length; i++)
                {
                    listViewItem.SubItems.Add(row[i]);
                }
                listViewUP.Items.Add(listViewItem);
            }
        }

        private void AdminViewUserProfile_Load(object sender, EventArgs e)
        {
            
            ListViewUP();
        }
    }
}
