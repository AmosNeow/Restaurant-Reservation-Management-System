﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;


namespace group_assignment__IOOP_
{

    public partial class Hall_Reservation_Detail : Form
    {
        
        public Hall_Reservation_Detail()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ReservationClass.pagew == 1 && ReservationClass.button == 4)
            {
                reservation_coordinator p = new reservation_coordinator();
                p.Show();
                this.Hide();
            }
            else 
            {
                this.Hide();
            }
            

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string query = "SELECT Reservation_Id,Number_of_people as num, Date ,time ,Hall FROM Reservation_Details";
            string selectedDate = dtpHall.Value.ToString("yyyy-MM-dd");
            int hall = Convert.ToInt32(cbHall.SelectedValue);

            if (chbAllHall.Checked == false && chbAllTime.Checked == true)
            {
                query += " WHERE Hall =@hall";
            }
            else if (chbAllHall.Checked == true && chbAllTime.Checked == false)
            {
                query += " where date = @date";

            }
            else if (chbAllHall.Checked == false && chbAllTime.Checked == false)
            {
                query += " WHERE Hall =@hall AND date = @date";

            }

            ReservationClass reservationData = new ReservationClass();
            dataGridView1.DataSource = reservationData.LoadData(query, selectedDate, hall);

        }

        private void Hall_Reservation_Detail_Load(object sender, EventArgs e)
        {
            ReservationClass load = new ReservationClass();
            load.LoadHall(cbHall, 1);
            dtpHall.Enabled = false;
            cbHall.Enabled = false;
            lblCapacity.Visible = false;
        }


        private void cbHall_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbHall.SelectedValue == null)
            {
                lblCapacity.Text = "";
                return;
            }

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString()))
            {
                conn.Open();
                string query = "SELECT Capacity FROM Hall_Details WHERE Hall_Id = @id";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(cbHall.SelectedValue));

                object result = cmd.ExecuteScalar();
                lblCapacity.Text = result != null ? result.ToString() : "N/A";
            }
        }

        private void chbSpecify_CheckedChanged(object sender, EventArgs e)
        {
            dtpHall.Enabled = !(chbAllTime.Checked);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            cbHall.Enabled = !(chbAllHall.Checked);
            if (chbAllHall.Checked)
            {
                lblCapacity.Visible = false;
            }
            else
            {
                lblCapacity.Visible = true;
            }
                
        }
    }


}
