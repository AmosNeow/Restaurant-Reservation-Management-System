﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace group_assignment__IOOP_
{
    public partial class AdminViewSalesReport: Form
    {
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public AdminViewSalesReport()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            AdminHomePage adminmenu = new AdminHomePage();
            adminmenu.Show();
            this.Close();
        }

        private void AdminViewSalesReport_Load(object sender, EventArgs e)
        {
            listViewSalesReport();
        }

        public static ArrayList ViewSRData()
        {
            ArrayList feedback = new ArrayList();
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Total_Amount_Paid", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                string result = $"{rd["User_ID"]}\t{rd["Total_Amount_Paid"]}";
                feedback.Add(result);
            }
            con.Close();
            return feedback;
        }

        public void listViewSalesReport()
        {
            listViewSR.Items.Clear();
            listViewSR.View = View.Details;
            listViewSR.Columns.Add("User ID", 100, HorizontalAlignment.Left);
            listViewSR.Columns.Add("Total_Amount_Paid", 100, HorizontalAlignment.Left);

            ArrayList profile1 = ViewSRData();
            foreach (var item in profile1)
            {
                string[] row = item.ToString().Split('\t');
                ListViewItem listViewItem = new ListViewItem(row[0]);
                for (int i = 1; i < row.Length; i++)
                {
                    listViewItem.SubItems.Add(row[i]);
                }
                listViewSR.Items.Add(listViewItem);
            }
        }
    }
}
