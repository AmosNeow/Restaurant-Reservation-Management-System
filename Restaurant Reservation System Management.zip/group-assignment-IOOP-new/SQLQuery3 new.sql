﻿CREATE TABLE [dbo].[Users] (
    [User_Id]      INT           IDENTITY (1, 1) NOT NULL,
    [Name]         NVARCHAR (50) NOT NULL,
    [Role]         NVARCHAR (50) NOT NULL,
    [Age]          INT           NOT NULL,
    [Phone_number] NVARCHAR (50) NOT NULL,
    [Email]        NVARCHAR (50) NOT NULL,
    [Password]     NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([User_Id] ASC)
);

CREATE TABLE [dbo].[Hall_Details] (
    [Hall_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Capacity] INT NOT NULL, 
    [Price] INT NOT NULL
);

CREATE TABLE [dbo].[Ingredient] (
    [Ingredient_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Quantity] INT NOT NULL
);

CREATE TABLE [dbo].[Menu] (
    [Food_Id]  INT           IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Category] NVARCHAR (50) NOT NULL,
    [Price]    FLOAT (53)    NOT NULL,
    PRIMARY KEY CLUSTERED ([Food_Id] ASC)
);


CREATE TABLE [dbo].[Order] (
    [Order_Id] INT           IDENTITY (1, 1) NOT NULL,
    [Food_Id]  INT           NOT NULL,
    [User_Id]  INT           NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Category] NVARCHAR (50) NOT NULL,
    [Price]    FLOAT (53)    NOT NULL,
    [Quantity] INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([Order_Id] ASC),
    FOREIGN KEY ([Food_Id]) REFERENCES [dbo].[Menu] ([Food_Id]),
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Order_Customer_Feedback] (
    [User_Id] INT NOT NULL, 
    [Feedback] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Order_Status] (
    [Status_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [User_Id] INT NOT NULL, 
    [Status] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Reservation_Details] (
    [Reservation_Id]   INT           IDENTITY (1, 1) NOT NULL,
    [User_Id]          INT           NOT NULL,
    [Number_of_People] INT           NOT NULL,
    [Date]             DATE          NOT NULL,
    [time]             TIME (7)      NOT NULL,
    [Theme]            NVARCHAR (50) NOT NULL,
    [Status]           NVARCHAR (50) NOT NULL,
    [Hall]             NVARCHAR(50)    NULL,
    PRIMARY KEY CLUSTERED ([Reservation_Id] ASC),
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
	ON DELETE CASCADE
);
CREATE TABLE [dbo].[Reservation_Feedback] (
    [User_Id] INT NOT NULL, 
    [Feedback] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Total_Amount_Paid] (
    [User_Id] INT NOT NULL, 
    [Total_Amount_Paid] FLOAT NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

SET IDENTITY_INSERT [dbo].[Menu] ON
INSERT INTO [dbo].[Menu] ([Food_Id], [Name], [Category], [Price]) VALUES (1, N'Nasi Lemak', N'Malay', 5)
INSERT INTO [dbo].[Menu] ([Food_Id], [Name], [Category], [Price]) VALUES (2, N'Dim Sum', N'Chinese', 2)
INSERT INTO [dbo].[Menu] ([Food_Id], [Name], [Category], [Price]) VALUES (3, N'Tosei', N'Indian', 3)
INSERT INTO [dbo].[Menu] ([Food_Id], [Name], [Category], [Price]) VALUES (4, N'Roti Canai', N'Indian', 2)
INSERT INTO [dbo].[Menu] ([Food_Id], [Name], [Category], [Price]) VALUES (5, N'Pao', N'Chinese', 3)
INSERT INTO [dbo].[Menu] ([Food_Id], [Name], [Category], [Price]) VALUES (6, N'Satay', N'Malay', 4)
SET IDENTITY_INSERT [dbo].[Menu] OFF

SET IDENTITY_INSERT [dbo].[Users] ON
INSERT INTO [dbo].[Users] ([User_Id], [Name], [Role], [Age], [Phone_number], [Email], [Password]) VALUES (1, N'Hexi', N'Admin', 46, N'0123456789', N'hexi@gmail.com', N'111')
INSERT INTO [dbo].[Users] ([User_Id], [Name], [Role], [Age], [Phone_number], [Email], [Password]) VALUES (3, N'Amos', N'Manager', 34, N'0128379888', N'amos@gmail.com', N'222')
INSERT INTO [dbo].[Users] ([User_Id], [Name], [Role], [Age], [Phone_number], [Email], [Password]) VALUES (5, N'Neng Jun', N'Reservation Coordinator', 18, N'01823877888', N'neng@gmail.com', N'333')
INSERT INTO [dbo].[Users] ([User_Id], [Name], [Role], [Age], [Phone_number], [Email], [Password]) VALUES (6, N'Ming Han', N'Customer', 24, N'0127384909', N'ming@gmail.com', N'666')
INSERT INTO [dbo].[Users] ([User_Id], [Name], [Role], [Age], [Phone_number], [Email], [Password]) VALUES (7, N'Zhi Xian', N'Chef', 21, N'018273842', N'xian@gmail.com', N'777')
SET IDENTITY_INSERT [dbo].[Users] OFF
