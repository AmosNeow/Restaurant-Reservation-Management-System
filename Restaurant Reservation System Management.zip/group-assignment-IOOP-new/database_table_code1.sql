﻿
CREATE TABLE [dbo].[Users] (
    [User_Id]      INT           IDENTITY (1, 1) NOT NULL,
    [Name]         NVARCHAR (50) NOT NULL,
    [Role]         NVARCHAR (50) NOT NULL,
    [Age]          INT           NOT NULL,
    [Phone_number] NVARCHAR (50) NOT NULL,
    [Email]        NVARCHAR (50) NOT NULL,
    [Password]     NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([User_Id] ASC)
);

CREATE TABLE [dbo].[Hall_Details] (
    [Hall_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Capacity] INT NOT NULL, 
    [Price] INT NOT NULL
);

CREATE TABLE [dbo].[Ingredient] (
    [Ingredient_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL, 
    [Quantity] INT NOT NULL
);

CREATE TABLE [dbo].[Menu] (
    [Food_Id]  INT           IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Category] NVARCHAR (50) NOT NULL,
    [Price]    FLOAT (53)    NOT NULL,
    PRIMARY KEY CLUSTERED ([Food_Id] ASC)
);


CREATE TABLE [dbo].[Order] (
    [Order_Id] INT           IDENTITY (1, 1) NOT NULL,
    [Food_Id]  INT           NOT NULL,
    [User_Id]  INT           NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Category] NVARCHAR (50) NOT NULL,
    [Price]    FLOAT (53)    NOT NULL,
    PRIMARY KEY CLUSTERED ([Order_Id] ASC),
    FOREIGN KEY ([Food_Id]) REFERENCES [dbo].[Menu] ([Food_Id]),
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Order_Customer_Feedback] (
    [User_Id] INT NOT NULL, 
    [Feedback] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Order_Status] (
    [Status_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [User_Id] INT NOT NULL, 
    [Status] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Reservation_Details] (
    [Reservation_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [User_Id] INT NOT NULL, 
    [Number_of_People] INT NOT NULL, 
    [Date_Time] DATETIME NOT NULL, 
    [Theme] NVARCHAR(50) NOT NULL, 
    [Status] NVARCHAR(50) NOT NULL, 
    [Hall] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Reservation_Feedback] (
    [User_Id] INT NOT NULL, 
    [Feedback] NVARCHAR(50) NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);

CREATE TABLE [dbo].[Total_Amount_Paid] (
    [User_Id] INT NOT NULL, 
    [Total_Amount_Paid] FLOAT NOT NULL,
    FOREIGN KEY ([User_Id]) REFERENCES [dbo].[Users] ([User_Id])
);
